package com.librarymanager_n10.dto;

public class LibraryLoanSlipDTO {
    private int id;
    private int idBook;
    private String idLibrarian;
    private int idMember;
    private String dateLoan;
    private int status;

    public LibraryLoanSlipDTO() {
        // Default constructor
    }

    public LibraryLoanSlipDTO(int id, int idBook, String idLibrarian, int idMember, String dateLoan, int status) {
        this.id = id;
        this.idBook = idBook;
        this.idLibrarian = idLibrarian;
        this.idMember = idMember;
        this.dateLoan = dateLoan;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdBook() {
        return idBook;
    }

    public void setIdBook(int idBook) {
        this.idBook = idBook;
    }

    public String getIdLibrarian() {
        return idLibrarian;
    }

    public void setIdLibrarian(String idLibrarian) {
        this.idLibrarian = idLibrarian;
    }

    public int getIdMember() {
        return idMember;
    }

    public void setIdMember(int idMember) {
        this.idMember = idMember;
    }

    public String getDateLoan() {
        return dateLoan;
    }

    public void setDateLoan(String dateLoan) {
        this.dateLoan = dateLoan;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Loan Slip ID: " + id + " | Book ID: " + idBook + " | Librarian ID: " + idLibrarian +
                " | Member ID: " + idMember + " | Loan Date: " + dateLoan + " | Status: " + status;
    }
}

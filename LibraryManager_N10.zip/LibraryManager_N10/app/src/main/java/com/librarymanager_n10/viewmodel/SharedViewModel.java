package com.librarymanager_n10.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;

public class SharedViewModel extends ViewModel {
    public final MutableLiveData<String> searchText = new MutableLiveData<>();

    public LiveData<String> getSearchText() { // Renamed for clarity if returning LiveData
        return searchText;
    }
}

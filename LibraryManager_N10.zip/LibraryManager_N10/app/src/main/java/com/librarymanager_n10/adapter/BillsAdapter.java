package com.librarymanager_n10.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.dao.MemberDAO;
import com.librarymanager_n10.databinding.DialogConfirmBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.databinding.ItemBillBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.dto.LibraryLoanSlipDTO;
import com.librarymanager_n10.dto.MemberDTO;
import com.librarymanager_n10.fragment.manager.ManagerBillsFragment;
import com.librarymanager_n10.ui.MainActivity;
import com.librarymanager_n10.ui.manager.DetailLoanActivity;
import com.librarymanager_n10.ui.manager.EditLoanActivity;

import java.util.ArrayList;
import java.util.List;

public class BillsAdapter extends RecyclerView.Adapter<BillsAdapter.BillsViewHolder> {

    private final List<LibraryLoanSlipDTO> listBills;
    private final BookDAO bookDAO;
    private final MemberDAO memberDAO;
    private final LibraryLoanSlipDAO libraryLoanSlipDAO;

    public BillsAdapter(Context context, ArrayList<LibraryLoanSlipDTO> listBills) {
        this.listBills = listBills;
        this.bookDAO = new BookDAO(context);
        this.memberDAO = new MemberDAO(context);
        this.libraryLoanSlipDAO = new LibraryLoanSlipDAO(context);
    }

    public static class BillsViewHolder extends RecyclerView.ViewHolder {
        private final ItemBillBinding binding;

        public BillsViewHolder(ItemBillBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(LibraryLoanSlipDTO libraryLoanSlipDTO, BookDAO bookDAO, MemberDAO memberDAO,
                         LibraryLoanSlipDAO libraryLoanSlipDAO, List<LibraryLoanSlipDTO> listBills) {
            BookDTO bookDTO = bookDAO.getBookByID(libraryLoanSlipDTO.getIdBook());
            //binding.txtNameBook.setText(binding.getRoot().getContext().getString(R.string.book_name) + bookDTO.getName());
            binding.txtNameBook.setText(binding.getRoot().getContext().getString(R.string.book_name) + bookDTO.getName());

            MemberDTO memberDTO = memberDAO.getMemberDTOById(libraryLoanSlipDTO.getIdMember());
            binding.txtNameMember.setText(binding.getRoot().getContext().getString(R.string.username) + memberDTO.getName());

            binding.txtDate.setText(binding.getRoot().getContext().getString(R.string.date_loan) + libraryLoanSlipDTO.getDateLoan());
            binding.txtPrice.setText(binding.getRoot().getContext().getString(R.string.rental_fee) + bookDTO.getRentalFee());

            binding.txtStatus.setText(libraryLoanSlipDTO.getStatus() == 0 ?
                    binding.getRoot().getContext().getString(R.string.not_returned) :
                    binding.getRoot().getContext().getString(R.string.returned));

            if (libraryLoanSlipDTO.getStatus() == 1) {
                binding.cardBaseInfor.setBackgroundResource(R.color.gray);
                binding.linearImageButton.setBackgroundResource(R.color.gray_light);
            }

            binding.cardBaseInfor.setOnClickListener(v -> {
                binding.cardImageButton.setVisibility(binding.cardImageButton.getVisibility() == View.GONE ? View.VISIBLE : View.GONE);
            });

            binding.btnDelete.setOnClickListener(v -> {
                AlertDialog.Builder builderConfirm = new AlertDialog.Builder(binding.getRoot().getContext());
                DialogConfirmBinding bindingConfirm = DialogConfirmBinding.inflate(LayoutInflater.from(binding.getRoot().getContext()));
                builderConfirm.setView(bindingConfirm.getRoot());
                AlertDialog dialogConfirm = builderConfirm.create();
                bindingConfirm.txtLoginSuccess.setText(binding.getRoot().getContext().getString(R.string.confirm_delete));

                bindingConfirm.btnNo.setOnClickListener(view -> dialogConfirm.dismiss());
                bindingConfirm.btnYes.setOnClickListener(view -> {
                    libraryLoanSlipDAO.deleteLoanSlip(libraryLoanSlipDTO.getId());
                    listBills.remove(libraryLoanSlipDTO);

                    ManagerBillsFragment fragment = new ManagerBillsFragment();
                    FragmentManager fragmentManager = ((MainActivity) binding.getRoot().getContext()).getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.nav_host_fragment, fragment).commit();

                    dialogConfirm.dismiss();
                    AlertDialog.Builder builderSuccess = new AlertDialog.Builder(binding.getRoot().getContext());
                    DialogLoginSuccessBinding bindingSuccess = DialogLoginSuccessBinding.inflate(LayoutInflater.from(binding.getRoot().getContext()));
                    builderSuccess.setView(bindingSuccess.getRoot());
                    AlertDialog dialogSuccess = builderSuccess.create();
                    bindingSuccess.txtLoginSuccess.setText(binding.getRoot().getContext().getString(R.string.delete_success));
                    bindingSuccess.btnLoginSuccess.setOnClickListener(view1 -> dialogSuccess.dismiss());
                    dialogSuccess.show();
                });

                dialogConfirm.show();
            });

            binding.btnInfo.setOnClickListener(v -> {
                Intent intent = new Intent(binding.getRoot().getContext(), DetailLoanActivity.class);
                intent.putExtra("idLoanSlip", String.valueOf(libraryLoanSlipDTO.getId()));
                binding.getRoot().getContext().startActivity(intent);
            });

            binding.btnEdit.setOnClickListener(v -> {
                Intent intent = new Intent(binding.getRoot().getContext(), EditLoanActivity.class);
                intent.putExtra("idLoanSlip", String.valueOf(libraryLoanSlipDTO.getId()));
                binding.getRoot().getContext().startActivity(intent);
            });
        }
    }

    @Override
    public BillsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemBillBinding binding = ItemBillBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new BillsViewHolder(binding);
    }

    @Override
    public int getItemCount() {
        return listBills.size();
    }

    @Override
    public void onBindViewHolder(@NonNull BillsViewHolder holder, int position) {
        holder.bind(listBills.get(position), bookDAO, memberDAO, libraryLoanSlipDAO, listBills);
    }
}

package com.librarymanager_n10.ui.manager;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.adapter.BookLoanAdapter;
import com.librarymanager_n10.adapter.LibrarianLoanAdapter;
import com.librarymanager_n10.adapter.MemberLoanAdapter;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.LibrarianDAO;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.dao.MemberDAO;
import com.librarymanager_n10.databinding.ActivityEditLoanBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.dto.LibrarianDTO;
import com.librarymanager_n10.dto.LibraryLoanSlipDTO;
import com.librarymanager_n10.dto.MemberDTO;
import com.librarymanager_n10.ui.MainActivity;

import java.util.ArrayList;

public class EditLoanActivity extends AppCompatActivity {

    private LibraryLoanSlipDAO loanSlipDAO;
    private LibraryLoanSlipDTO loanSlipDTO;

    private BookDAO bookDAO;
    private BookDTO bookDTO;

    private MemberDAO memberDAO;
    private MemberDTO memberDTO;

    private LibrarianDAO librarianDAO;
    private LibrarianDTO librarianDTO;

    private BookLoanAdapter bookLoanAdapter;
    private MemberLoanAdapter memberLoanAdapter;
    private LibrarianLoanAdapter librarianLoanAdapter;

    private ArrayList<BookDTO> listBook;
    private ArrayList<MemberDTO> listMember;
    private ArrayList<LibrarianDTO> listLibrarian;

    private ActivityEditLoanBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditLoanBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbarEditLoan);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        memberDAO = new MemberDAO(this);
        listMember = memberDAO.getAllMember();

        bookDAO = new BookDAO(this);
        listBook = bookDAO.getAllBook();

        librarianDAO = new LibrarianDAO(this);
        listLibrarian = librarianDAO.getAllLibrarian();

        bookLoanAdapter = new BookLoanAdapter(this, listBook);
        memberLoanAdapter = new MemberLoanAdapter(this, listMember);
        librarianLoanAdapter = new LibrarianLoanAdapter(this, listLibrarian);

        binding.spinnerEditLoanNameBook.setAdapter(bookLoanAdapter);
        binding.spinnerEditLibrarianNameMember.setAdapter(librarianLoanAdapter);
        binding.spinnerEditMemberBookMember.setAdapter(memberLoanAdapter);

        binding.spinnerEditLibrarianNameMember.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                librarianDTO = listLibrarian.get(position);
                binding.spinnerEditLibrarianNameMember.setHint("Tên thủ thư");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        binding.spinnerEditMemberBookMember.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                memberDTO = listMember.get(position);
                binding.spinnerEditMemberBookMember.setHint("Tên thành viên");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        binding.spinnerEditLoanNameBook.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                bookDTO = listBook.get(position);
                binding.spinnerEditLoanNameBook.setHint("Tên sách");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        binding.edtFromDateLoan.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(EditLoanActivity.this);
            datePickerDialog.setOnDateSetListener((view, year, month, dayOfMonth) -> {
                String selectedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                if (selectedDate.isEmpty()) {
                    Toast.makeText(EditLoanActivity.this, "Chưa chọn ngày", Toast.LENGTH_SHORT).show();
                } else {
                    binding.edtFromDateLoan.setText(selectedDate);
                }
            });
            datePickerDialog.show();
        });

        Intent intent = getIntent();
        String idLoanSlipStr = intent.getStringExtra("idLoanSlip");

        // Lấy dữ liệu từ cơ sở dữ liệu
        try {
            if (idLoanSlipStr != null) {
                loanSlipDAO = new LibraryLoanSlipDAO(this);
                loanSlipDTO = loanSlipDAO.getLoanSlipByID(Integer.parseInt(idLoanSlipStr));

                // Lấy sách theo ID
                bookDAO = new BookDAO(this);
                bookDTO = bookDAO.getBookByID(loanSlipDTO.getIdBook());

                // Lấy thành viên theo ID
                memberDAO = new MemberDAO(this);
                memberDTO = memberDAO.getMemberDTOById(loanSlipDTO.getIdMember());

                // Lấy thủ thư theo ID
                librarianDAO = new LibrarianDAO(this);
                librarianDTO = librarianDAO.getLibrarianByID(loanSlipDTO.getIdLibrarian());
                int selectedLibrarianPosition = 0,
                        selectedMemberPosition = 0,
                        selectedBookPosition = 0,
                        index = 0;
                // Đặt giá trị cho Spinner
                for (LibrarianDTO l : listLibrarian) {
                    if (l.getId().equals(loanSlipDTO.getIdLibrarian()))
                        break;
                    selectedLibrarianPosition++;
                }
                for (MemberDTO m : listMember) {
                    if (m.getId() == loanSlipDTO.getIdMember())
                        break;
                    selectedMemberPosition++;
                }
                for (BookDTO b : listBook) {
                    if (b.getIdBook() == loanSlipDTO.getIdBook())
                        break;
                    selectedBookPosition++;
                }
                binding.spinnerEditLibrarianNameMember.setSelection(selectedLibrarianPosition);

                binding.spinnerEditMemberBookMember.setSelection(selectedMemberPosition);

                binding.spinnerEditLoanNameBook.setSelection(selectedBookPosition);

                // Đặt giá trị cho EditText
                binding.edtFromDateLoan.setText(loanSlipDTO.getDateLoan());

                // Đặt trạng thái cho RadioGroup
                if (loanSlipDTO.getStatus() == 1) {
                    binding.radioGroupLoan.check(R.id.radio_return_loan);
                } else {
                    binding.radioGroupLoan.check(R.id.radio_not_return_loan);
                }
            }
        } catch (NumberFormatException e) {
            Log.e("LoanSlipError", "Lỗi chuyển đổi ID: " + e.getMessage());
        } catch (Exception e) {
            Log.e("LoanSlipError", "Lỗi chung: " + e.getMessage());
        }


        binding.btnCancelEditLoan.setOnClickListener(v -> finish());

        binding.btnSaveEditLoan.setOnClickListener(v -> {
            int status = binding.radioReturnLoan.isChecked() ? 1 : 0;
            String date = binding.edtFromDateLoan.getText().toString();
            int idBook = bookDTO.getIdBook();
            int idMember = memberDTO.getId();
            String idLibrarian = librarianDTO.getId();

            loanSlipDTO = new LibraryLoanSlipDTO(Integer.parseInt(idLoanSlipStr), idBook, idLibrarian, idMember, date, status);
            boolean result = loanSlipDAO.updateLoanSlip(loanSlipDTO);

            if (result) {
                AlertDialog.Builder builderSuccess = new AlertDialog.Builder(this, R.style.CustomDialog);
                DialogLoginSuccessBinding bindingSuccess = DialogLoginSuccessBinding.inflate(getLayoutInflater());
                builderSuccess.setView(bindingSuccess.getRoot());
                AlertDialog dialogSuccess = builderSuccess.create();
                dialogSuccess.show();
                dialogSuccess.setCancelable(false);

                bindingSuccess.txtLoginSuccess.setText("Sửa thành công phiếu mượn!");
                bindingSuccess.btnLoginSuccess.setOnClickListener(view -> {
                    Intent intentMain = new Intent(this, MainActivity.class);
                    intentMain.putExtra("ok", "ok");
                    startActivity(intentMain);
                    finish();
                });
            } else {
                Toast.makeText(this, "Sửa lỗi", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

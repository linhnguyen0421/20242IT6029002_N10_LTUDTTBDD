package com.librarymanager_n10.fragment.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.librarymanager_n10.adapter.MemberAdapter;
import com.librarymanager_n10.dao.MemberDAO;
import com.librarymanager_n10.databinding.FragmentManagerMembersBinding;
import com.librarymanager_n10.dto.MemberDTO;
import com.librarymanager_n10.ui.manager.AddMemberActivity;
import com.librarymanager_n10.viewmodel.SharedViewModel;

import java.util.ArrayList;

public class ManagerMembersFragment extends Fragment {

    private FragmentManagerMembersBinding binding;
    private MemberAdapter adapter;
    private ArrayList<MemberDTO> listMember;
    private MemberDAO memberDAO;
    private SharedViewModel sharedViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentManagerMembersBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.managerMembersRecyclerView.setHasFixedSize(true);
        binding.managerMembersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        memberDAO = new MemberDAO(requireContext());
        listMember = memberDAO.getAllMember();

        if (!listMember.isEmpty()) {
            adapter = new MemberAdapter(requireContext(), listMember);
            binding.managerMembersRecyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }

        String data = getArguments() != null ? getArguments().getString("ok") : null;
        if ("member".equals(data)) {
            refresh();
        }

        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        sharedViewModel.getSearchText().observe(getViewLifecycleOwner(), newText -> {
            ArrayList<MemberDTO> filterList = new ArrayList<>();
            for (MemberDTO member : listMember) {
                if (member.getName().toLowerCase().contains(newText.toLowerCase())) {
                    filterList.add(member);
                }
            }

            MemberAdapter filteredAdapter = new MemberAdapter(requireContext(), filterList);
            binding.managerMembersRecyclerView.setAdapter(filteredAdapter);
            filteredAdapter.notifyDataSetChanged();
        });

        binding.fabMembersBill.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AddMemberActivity.class);
            startActivity(intent);
        });
    }

    private void refresh() {
        listMember.clear();
        listMember.addAll(memberDAO.getAllMember());
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

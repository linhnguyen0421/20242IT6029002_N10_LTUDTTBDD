package com.librarymanager_n10.fragment.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.librarymanager_n10.adapter.BooksAdapter;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.databinding.FragmentManagerBooksBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.ui.manager.AddBookActivity;
import com.librarymanager_n10.viewmodel.SharedViewModel;

import java.util.ArrayList;

public class ManagerBooksFragment extends Fragment {

    private FragmentManagerBooksBinding binding;
    private BookDAO bookDAO;
    private ArrayList<BookDTO> listBook;
    private BooksAdapter adapter;
    private SharedViewModel sharedViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentManagerBooksBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.managerBooksRecyclerView.setHasFixedSize(true);
        binding.managerBooksRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        bookDAO = new BookDAO(requireContext());
        listBook = bookDAO.getAllBook();

        if (!listBook.isEmpty()) {
            adapter = new BooksAdapter(requireContext(), listBook);
            binding.managerBooksRecyclerView.setAdapter(adapter);
            binding.managerBooksRecyclerView.setVisibility(View.VISIBLE);
            adapter.notifyDataSetChanged();
        }

        String data = getArguments() != null ? getArguments().getString("ok") : null;
        if ("bookOK".equals(data)) {
            refreshList();
        }

        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        sharedViewModel.getSearchText().observe(getViewLifecycleOwner(), newText -> {
            ArrayList<BookDTO> filterList = new ArrayList<>();
            for (BookDTO book : listBook) {
                if (book.getName().toLowerCase().contains(newText.toLowerCase())) {
                    filterList.add(book);
                }
            }

            BooksAdapter filteredAdapter = new BooksAdapter(requireContext(), filterList);
            binding.managerBooksRecyclerView.setAdapter(filteredAdapter);
            filteredAdapter.notifyDataSetChanged();
        });

        binding.fabAddBooks.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AddBookActivity.class);
            startActivity(intent);
        });
    }

    private void refreshList() {
        listBook.clear();
        listBook = bookDAO.getAllBook();
        BooksAdapter newAdapter = new BooksAdapter(requireContext(), listBook);
        binding.managerBooksRecyclerView.setAdapter(newAdapter);
        newAdapter.notifyDataSetChanged();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}

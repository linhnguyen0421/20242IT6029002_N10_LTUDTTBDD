package com.librarymanager_n10.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.librarymanager_n10.R;
import com.librarymanager_n10.databinding.ActivityMainBinding;
import com.librarymanager_n10.fragment.account.AddNewUserFragment;
import com.librarymanager_n10.fragment.account.ChangePasswordFragment;
import com.librarymanager_n10.fragment.account.ProfileFragment;
import com.librarymanager_n10.fragment.manager.ManagerBillsFragment;
import com.librarymanager_n10.fragment.manager.ManagerBooksFragment;
import com.librarymanager_n10.fragment.manager.ManagerCategoryBooksFragment;
import com.librarymanager_n10.fragment.manager.ManagerMembersFragment;
import com.librarymanager_n10.fragment.statistical.RevenueFragment;
import com.librarymanager_n10.fragment.statistical.Top10Fragment;
import com.librarymanager_n10.sharepre.LoginSharePreference;
import com.librarymanager_n10.ui.account.LoginActivity;
import com.librarymanager_n10.viewmodel.SharedViewModel;

public class MainActivity extends AppCompatActivity {

    private ActionBarDrawerToggle toggle;
    private ActivityMainBinding binding;
    private LoginSharePreference loginSharePreference;
    private Fragment currentFragment;
    private SharedViewModel sharedViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        toggle = new ActionBarDrawerToggle(this, binding.drawerLayout, R.string.open, R.string.close);
        binding.drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        setSupportActionBar(binding.toolbar);

        if (savedInstanceState == null) {
            currentFragment = new ManagerBillsFragment();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment, currentFragment)
                    .commit();
            getSupportActionBar().setTitle(R.string.manager_bill);
            invalidateOptionsMenu();
        }

        // Intent navigation
        String data = getIntent().getStringExtra("ok");
        if (data != null) {
            Fragment fragment = null;
            Bundle bundle = new Bundle();
            bundle.putString("ok", data);
            switch (data) {
                case "ok":
                    fragment = new ManagerBillsFragment();
                    break;
                case "category":
                    fragment = new ManagerCategoryBooksFragment();
                    break;
                case "member":
                    fragment = new ManagerMembersFragment();
                    break;
                case "bookOK":
                    fragment = new ManagerBooksFragment();
                    break;
            }
            if (fragment != null) {
                fragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.nav_host_fragment, fragment)
                        .commit();
            }
        }

        // User info
        loginSharePreference = new LoginSharePreference(this);
        String username = loginSharePreference.getID();
        String fullname = loginSharePreference.getName();
        String role = loginSharePreference.getRole();

        TextView userNameTextView = binding.navView.getHeaderView(0).findViewById(R.id.user_name);
        TextView userFullNameTextView = binding.navView.getHeaderView(0).findViewById(R.id.user_full_name);
        TextView userRole = binding.navView.getHeaderView(0).findViewById(R.id.txt_role);

        userNameTextView.setText(username);
        userFullNameTextView.setText(fullname);
        userRole.setText(role);

        if (!"admin".equals(role)) {
            binding.navView.getMenu().findItem(R.id.add_user).setVisible(false);
        }

        binding.navView.setNavigationItemSelectedListener(menuItem -> {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            Fragment currentFragment = null;

            int itemId = menuItem.getItemId();

            if (itemId == R.id.manager_bill) {
                currentFragment = new ManagerBillsFragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.manager_bill));
            } else if (itemId == R.id.manager_book) {
                currentFragment = new ManagerBooksFragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.manager_book));
            } else if (itemId == R.id.manager_user) {
                currentFragment = new ManagerMembersFragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.manager_user));
            } else if (itemId == R.id.manager_category) {
                currentFragment = new ManagerCategoryBooksFragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.manager_category_book));
            } else if (itemId == R.id.user_profile) {
                currentFragment = new ProfileFragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.profile));
            } else if (itemId == R.id.change_password) {
                currentFragment = new ChangePasswordFragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.change_password));
            } else if (itemId == R.id.add_user) {
                currentFragment = new AddNewUserFragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.create_new_account));
            } else if (itemId == R.id.top10) {
                currentFragment = new Top10Fragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.top_10_book));
            } else if (itemId == R.id.money) {
                currentFragment = new RevenueFragment();
                getSupportActionBar().setTitle(getResources().getString(R.string.revenue));
            } else if (itemId == R.id.logout) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Logout")
                        .setMessage("Do you want to logout?")
                        .setIcon(R.drawable.user)
                        .setPositiveButton("Yes", (dialog, which) -> {
                            LoginSharePreference loginSharePreference = new LoginSharePreference(this);
                            loginSharePreference.clearLogin();
                            Intent intent = new Intent(this, LoginActivity.class);
                            startActivity(intent);
                            finish();
                        })
                        .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                        .show();
            }

            if (currentFragment != null) {
                fragmentTransaction.replace(R.id.nav_host_fragment, currentFragment);
                fragmentTransaction.commit();
            }

            invalidateOptionsMenu();
            binding.drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });
    }

    private void updateUserInformation() {
        String username = loginSharePreference.getID();
        String fullname = loginSharePreference.getName();
        String role = loginSharePreference.getRole();

        TextView userNameTextView = binding.navView.getHeaderView(0).findViewById(R.id.user_name);
        TextView userFullNameTextView = binding.navView.getHeaderView(0).findViewById(R.id.user_full_name);
        TextView userRole = binding.navView.getHeaderView(0).findViewById(R.id.txt_role);

        userNameTextView.setText(username);
        userFullNameTextView.setText(fullname);
        userRole.setText(role);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUserInformation();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setQueryHint("Search...");

        sharedViewModel = new ViewModelProvider(this).get(SharedViewModel.class);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                sharedViewModel.searchText.setValue(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                sharedViewModel.searchText.setValue(newText);
                return false;
            }
        });

        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (menu == null) return super.onPrepareOptionsMenu(menu);
        boolean showSearch = currentFragment instanceof ManagerBillsFragment
                || currentFragment instanceof ManagerBooksFragment
                || currentFragment instanceof ManagerCategoryBooksFragment
                || currentFragment instanceof ManagerMembersFragment
                || currentFragment instanceof Top10Fragment;
        menu.findItem(R.id.action_search).setVisible(showSearch);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return toggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }

    @Override
    @Deprecated
    public void onBackPressed() {
        super.onBackPressed();
        if (!loginSharePreference.getRemember()) {
            loginSharePreference.clearLogin();
        }
    }
}

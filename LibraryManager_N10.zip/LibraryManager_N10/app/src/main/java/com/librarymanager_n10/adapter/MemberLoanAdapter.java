package com.librarymanager_n10.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.librarymanager_n10.databinding.ItemMembersLoanBinding;
import com.librarymanager_n10.dto.MemberDTO;

import java.util.ArrayList;

public class MemberLoanAdapter extends ArrayAdapter<MemberDTO> {

    private final Context context;

    public MemberLoanAdapter(@NonNull Context context, @NonNull ArrayList<MemberDTO> listMembers) {
        super(context, 0, listMembers);
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, parent);
    }

    @NonNull
    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, parent);
    }

    private View initView(int position, ViewGroup parent) {
        ItemMembersLoanBinding binding = ItemMembersLoanBinding.inflate(LayoutInflater.from(context), parent, false);

        MemberDTO member = getItem(position);
        if (member != null) {
            binding.txtItemMemberName.setText(member.getName());
        }

        return binding.getRoot();
    }
}

package com.librarymanager_n10.ui.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.adapter.BookLoanAdapter;
import com.librarymanager_n10.adapter.MemberLoanAdapter;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.dao.MemberDAO;
import com.librarymanager_n10.databinding.ActivityAddLoanBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.dto.LibraryLoanSlipDTO;
import com.librarymanager_n10.dto.MemberDTO;
import com.librarymanager_n10.sharepre.LoginSharePreference;
import com.librarymanager_n10.ui.MainActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class AddLoanActivity extends AppCompatActivity {

    private ActivityAddLoanBinding binding;
    private ArrayList<BookDTO> listBooks;
    private ArrayList<MemberDTO> listMembers;
    private BookDTO book;
    private MemberDTO member;
    private BookLoanAdapter bookAdapter;
    private MemberLoanAdapter memberAdapter;
    private MemberDAO memberDAO;
    private BookDAO bookDAO;
    private LoginSharePreference userSharePreferences;
    private LibraryLoanSlipDTO libraryLoanSlipDTO;
    private LibraryLoanSlipDAO libraryLoanSlipDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddLoanBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbarAddLoan);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        bookDAO = new BookDAO(this);
        listBooks = bookDAO.getAllBook();

        memberDAO = new MemberDAO(this);
        listMembers = memberDAO.getAllMember();

        bookAdapter = new BookLoanAdapter(this, listBooks);
        memberAdapter = new MemberLoanAdapter(this, listMembers);

        binding.spinnerAddLoanNameBook.setAdapter(bookAdapter);
        binding.spinnerAddLoanNameMember.setAdapter(memberAdapter);

        binding.spinnerAddLoanNameBook.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                book = listBooks.get(position);
                binding.spinnerAddLoanNameBook.setHint(book.getName());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        binding.spinnerAddLoanNameMember.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                member = listMembers.get(position);
                binding.spinnerAddLoanNameMember.setHint(member.getName());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        binding.btnCancelAddLoan.setOnClickListener(v -> finish());

        binding.btnAddLoan.setOnClickListener(v -> {
            if (binding.spinnerAddLoanNameBook.getSelectedItem() == null) {
                binding.spinnerAddLoanNameBook.setErrorText("Please choose book");
                Toast.makeText(this, "Please choose book", Toast.LENGTH_SHORT).show();
                return;
            } else {
                binding.spinnerAddLoanNameBook.setErrorText("");
            }

            if (binding.spinnerAddLoanNameMember.getSelectedItem() == null) {
                binding.spinnerAddLoanNameMember.setErrorText("Please choose member");
                Toast.makeText(this, "Please choose member", Toast.LENGTH_SHORT).show();
                return;
            } else {
                binding.spinnerAddLoanNameMember.setErrorText("");
            }

            Date currentDateTime = Calendar.getInstance().getTime();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String date = dateFormat.format(currentDateTime);

            userSharePreferences = new LoginSharePreference(this);
            String idLibrarian = userSharePreferences.getID();
            if (idLibrarian == null) idLibrarian = "";

            int idBook = book.getIdBook();
            int idMember = member.getId();

            libraryLoanSlipDTO = new LibraryLoanSlipDTO(0, idBook, idLibrarian, idMember, date, 0);
            libraryLoanSlipDAO = new LibraryLoanSlipDAO(this);
            boolean result = libraryLoanSlipDAO.insertLoanSlip(libraryLoanSlipDTO);

            if (result) {
                AlertDialog.Builder builderSuccess = new AlertDialog.Builder(this, R.style.CustomDialog);
                DialogLoginSuccessBinding bindingSuccess = DialogLoginSuccessBinding.inflate(getLayoutInflater());
                builderSuccess.setView(bindingSuccess.getRoot());
                AlertDialog dialogSuccess = builderSuccess.create();
                dialogSuccess.setCancelable(false);
                dialogSuccess.show();

                bindingSuccess.txtLoginSuccess.setText("Thêm thành công phiếu mượn!");
                bindingSuccess.btnLoginSuccess.setOnClickListener(view -> {
                    Intent intent = new Intent(this, MainActivity.class);
                    intent.putExtra("ok", "ok");
                    startActivity(intent);
                    finish();
                });
            } else {
                Toast.makeText(this, "Thêm phiếu mượn lỗi", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

package com.librarymanager_n10.ui.account;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.LibrarianDAO;
import com.librarymanager_n10.databinding.ActivityEditUserBinding;
import com.librarymanager_n10.dto.LibrarianDTO;
import com.librarymanager_n10.sharepre.LoginSharePreference;

public class EditAccountActivity extends AppCompatActivity {

    // Shared Preference
    private LoginSharePreference userSharePreference;

    // Database
    private LibrarianDTO librarianDTO;
    private LibrarianDAO librarianDAO;

    // View Binding
    private ActivityEditUserBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditUserBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set toolbar
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Get user info
        userSharePreference = new LoginSharePreference(this);
        String id = userSharePreference.getID();

        if (id != null) {
            librarianDAO = new LibrarianDAO(this);
            librarianDTO = librarianDAO.getLibrarianByID(id);

            binding.edtUsernameProfile.setText(librarianDTO.getId());
            binding.edtFullnameProfile.setText(librarianDTO.getName());

            binding.edtUsernameProfile.setOnClickListener(v ->
                    Toast.makeText(this, "Không thể sửa", Toast.LENGTH_SHORT).show()
            );

            binding.btnCancelEditUser.setOnClickListener(v -> finish());

            binding.btnSaveEditUser.setOnClickListener(v -> {
                String username = binding.edtUsernameProfile.getText().toString().trim();
                String fullname = binding.edtFullnameProfile.getText().toString().trim();

                if (username.isEmpty()) {
                    binding.edtUsernameProfile.setError("Tên người dùng trống");
                    return;
                }

                if (fullname.isEmpty()) {
                    binding.edtFullnameProfile.setError("Tên đầy đủ trống");
                    return;
                }

                librarianDTO = new LibrarianDTO(username, fullname, librarianDTO.getPassword(), librarianDTO.getRole());
                long result = librarianDAO.editLibrarian(librarianDTO);

                if (result > 0) {
                    userSharePreference.saveLogin(librarianDTO);
                    finish();
                } else {
                    Toast.makeText(this, "Edit failed", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

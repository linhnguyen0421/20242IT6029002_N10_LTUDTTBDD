package com.librarymanager_n10.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.databinding.ActivityWelcomeBinding;
import com.librarymanager_n10.ui.account.LoginActivity;

import java.util.Timer;
import java.util.TimerTask;

public class WelcomeActivity extends AppCompatActivity {
    private ActivityWelcomeBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityWelcomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> navigateToLogin());
            }
        }, 1500); // 1500 milliseconds delay
    }

    private void navigateToLogin() {
        Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}

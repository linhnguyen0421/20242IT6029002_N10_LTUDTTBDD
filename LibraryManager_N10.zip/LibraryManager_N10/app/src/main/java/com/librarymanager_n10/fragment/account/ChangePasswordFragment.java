package com.librarymanager_n10.fragment.account;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.LibrarianDAO;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.databinding.DialogProccessingBinding;
import com.librarymanager_n10.databinding.FragmentChangePasswordBinding;
import com.librarymanager_n10.dto.LibrarianDTO;
import com.librarymanager_n10.sharepre.LoginSharePreference;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChangePasswordFragment extends Fragment {

    private FragmentChangePasswordBinding binding;
    private LoginSharePreference userSharePreference;
    private LibrarianDTO librarianDTO;
    private LibrarianDAO librarianDAO;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentChangePasswordBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        userSharePreference = new LoginSharePreference(requireContext());
        String password = userSharePreference.getPassword();
        String username = userSharePreference.getID();

        librarianDAO = new LibrarianDAO(requireContext());
        librarianDTO = librarianDAO.getLibrarianByID(username);

        binding.btnConfirmChangePassword.setOnClickListener(v -> {
            String oldPassword = binding.edtOldPassword.getText().toString().trim();
            if (oldPassword.isEmpty()) {
                binding.edtOldPassword.setError("Old password is empty");
                return;
            }
            if (!oldPassword.equals(password)) {
                binding.edtOldPassword.setError("Old password is incorrect");
                return;
            }

            if (binding.linearlayoutOldPassword.getVisibility() == View.VISIBLE) {
                binding.linearlayoutOldPassword.setVisibility(View.GONE);
                binding.linearlayoutChangePassword.setVisibility(View.VISIBLE);
                binding.btnConfirmChangePassword.setVisibility(View.GONE);
                binding.tvChangePassword.setText("Đặt mật khẩu mới");
                binding.imgLock.setImageResource(R.drawable.user_profile);
            }
        });

        binding.btnConfirm.setOnClickListener(v -> {
            String newPassword = binding.edtNewPassword.getText().toString().trim();
            String confirmPassword = binding.edtConfirmNewPassword.getText().toString().trim();

            if (newPassword.isEmpty()) {
                binding.edtNewPassword.setError("New password is empty");
                return;
            }
            if (confirmPassword.isEmpty()) {
                binding.edtConfirmNewPassword.setError("Confirm password is empty");
                return;
            }
            if (!newPassword.equals(confirmPassword)) {
                binding.edtConfirmNewPassword.setError("Confirm password is incorrect");
                return;
            }

            executor.execute(() -> {
                librarianDTO = new LibrarianDTO(username, librarianDTO.getName(), newPassword, librarianDTO.getRole());
                long result = librarianDAO.editLibrarian(librarianDTO);

                mainHandler.post(() -> {
                    if (result > 0) {
                        userSharePreference.saveLogin(librarianDTO);
                        showProcessingDialog("Đang đổi mật khẩu");
                        mainHandler.postDelayed(() -> showSuccessDialog("Đổi mật khẩu thành công"), 1000);
                    } else {
                        showErrorDialog();
                    }
                });
            });
        });

        binding.btnConfirmCancel.setOnClickListener(v -> resetPasswordForm());
    }

    private void resetPasswordForm() {
        binding.linearlayoutOldPassword.setVisibility(View.VISIBLE);
        binding.linearlayoutChangePassword.setVisibility(View.GONE);
        binding.btnConfirmChangePassword.setVisibility(View.VISIBLE);
        binding.tvChangePassword.setText("Đổi mật khẩu");
        binding.edtOldPassword.setText("");
        binding.edtNewPassword.setText("");
        binding.edtConfirmNewPassword.setText("");
        binding.imgLock.setImageResource(R.drawable.ok);
    }

    private void showProcessingDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext(), R.style.CustomDialog);
        DialogProccessingBinding dialogBinding = DialogProccessingBinding.inflate(getLayoutInflater());
        dialogBinding.textViewLoading.setText(message);
        builder.setView(dialogBinding.getRoot());
        builder.setCancelable(false);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void showSuccessDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext(), R.style.CustomDialog);
        DialogLoginSuccessBinding dialogBinding = DialogLoginSuccessBinding.inflate(getLayoutInflater());
        dialogBinding.txtLoginSuccess.setText(message);
        AlertDialog dialog = builder.setView(dialogBinding.getRoot()).create();
        dialogBinding.btnLoginSuccess.setOnClickListener(v -> {
            resetPasswordForm();
            dialog.dismiss();
        });
        dialog.show();
    }

    private void showErrorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext(), R.style.CustomDialog);
        DialogLoginSuccessBinding dialogBinding = DialogLoginSuccessBinding.inflate(getLayoutInflater());
        dialogBinding.txtLoginSuccess.setText("Đổi mật khẩu thất bại");
        dialogBinding.btnLoginSuccess.setText("Thử lại");
        dialogBinding.imgSuccess.setImageResource(R.drawable.error);
        AlertDialog dialog = builder.setView(dialogBinding.getRoot()).create();
        dialogBinding.btnLoginSuccess.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        binding = null;
        executor.shutdown();
    }
}

package com.librarymanager_n10.dto;

public class BookDTO {
    private int idBook;
    private String name;
    private int rentalFee;
    private int category;
    private int timeRental;

    public BookDTO(int idBook, String name, int rentalFee, int category, int timeRental) {
        this.idBook = idBook;
        this.name = name;
        this.rentalFee = rentalFee;
        this.category = category;
        this.timeRental = timeRental;
    }

    public BookDTO(int idBook, String name, int rentalFee, int category) {
        this(idBook, name, rentalFee, category, 0); // Default timeRental to 0 if not provided
    }

    public int getIdBook() {
        return idBook;
    }

    public void setIdBook(int idBook) {
        this.idBook = idBook;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRentalFee() {
        return rentalFee;
    }

    public void setRentalFee(int rentalFee) {
        this.rentalFee = rentalFee;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public int getTimeRental() {
        return timeRental;
    }

    public void setTimeRental(int timeRental) {
        this.timeRental = timeRental;
    }

    @Override
    public String toString() {
        // Return id + name + rentalFee + category
        return idBook + " - " + name + " - " + rentalFee + " - " + category;
    }
}

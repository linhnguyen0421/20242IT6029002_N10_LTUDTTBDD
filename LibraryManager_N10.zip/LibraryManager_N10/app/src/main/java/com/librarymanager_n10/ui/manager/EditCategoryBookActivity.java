package com.librarymanager_n10.ui.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.CategoryBookDAO;
import com.librarymanager_n10.databinding.ActivityEditCategoryBookBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.dto.CategoryBookDTO;
import com.librarymanager_n10.ui.MainActivity;

public class EditCategoryBookActivity extends AppCompatActivity {

    private ActivityEditCategoryBookBinding binding;
    private CategoryBookDAO categoryBookDAO;
    private CategoryBookDTO categoryBookDTO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditCategoryBookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbarEditCategoryBook);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Get intent data
        String idCategoryBook = getIntent().getStringExtra("idCategory");
        if (idCategoryBook != null) {
            categoryBookDAO = new CategoryBookDAO(this);
            categoryBookDTO = categoryBookDAO.getCategoryBookById(Integer.parseInt(idCategoryBook));

            // Set text fields
            binding.edtIdCategory.setText(String.valueOf(categoryBookDTO.getId()));
            binding.edtNameCategory.setText(categoryBookDTO.getName());
        }

        // Prevent ID editing
        binding.edtIdCategory.setOnClickListener(v ->
                Toast.makeText(this, "Không thể thay đổi mã loại sách!", Toast.LENGTH_SHORT).show()
        );

        // Cancel button
        binding.btnCancelEditCategoryBook.setOnClickListener(v -> finish());

        // Save button
        binding.btnSaveEditCategoryBook.setOnClickListener(v -> {
            String idCategoryStr = binding.edtIdCategory.getText().toString();
            String nameCategory = binding.edtNameCategory.getText().toString();

            if (nameCategory.isEmpty()) {
                binding.edtNameCategory.setError("Tên loại sách không được để trống");
            } else {
                CategoryBookDTO updatedCategory =
                        new CategoryBookDTO(Integer.parseInt(idCategoryStr), nameCategory);
                int result = categoryBookDAO.updateCategoryBook(updatedCategory);
                if (result > 0) {
                    AlertDialog.Builder builderSuccess = new AlertDialog.Builder(this, R.style.CustomDialog);
                    DialogLoginSuccessBinding bindingSuccess =
                            DialogLoginSuccessBinding.inflate(getLayoutInflater());

                    builderSuccess.setView(bindingSuccess.getRoot());
                    AlertDialog dialogSuccess = builderSuccess.create();
                    dialogSuccess.show();
                    dialogSuccess.setCancelable(false);

                    bindingSuccess.txtLoginSuccess.setText("Sửa loại sách thành công");
                    bindingSuccess.btnLoginSuccess.setOnClickListener(dialogView -> {
                        dialogSuccess.dismiss();
                        Intent intent = new Intent(this, MainActivity.class);
                        intent.putExtra("ok", "category");
                        startActivity(intent);
                        finish();
                    });
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

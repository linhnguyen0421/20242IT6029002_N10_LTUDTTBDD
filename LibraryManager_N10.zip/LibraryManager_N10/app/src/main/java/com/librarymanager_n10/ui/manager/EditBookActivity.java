package com.librarymanager_n10.ui.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.adapter.CategoryAddBookAdapter;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.CategoryBookDAO;
import com.librarymanager_n10.databinding.ActivityEditBookBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.dto.CategoryBookDTO;
import com.librarymanager_n10.ui.MainActivity;

import java.util.ArrayList;

public class EditBookActivity extends AppCompatActivity {

    private ActivityEditBookBinding binding;
    private CategoryBookDAO categoryBookDAO;
    private CategoryBookDTO categoryBookDTO;
    private BookDTO bookDTO;
    private BookDAO bookDAO;
    private ArrayList<CategoryBookDTO> listCategoryBook;
    private CategoryAddBookAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditBookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbarEditBook);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Get all category books
        categoryBookDAO = new CategoryBookDAO(this);
        listCategoryBook = categoryBookDAO.getAllCategoryBooks();

        // Setup adapter for spinner
        adapter = new CategoryAddBookAdapter(this, listCategoryBook);
        binding.spinnerEditBookCategory.setAdapter(adapter);

        // Spinner item selection listener
        binding.spinnerEditBookCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                categoryBookDTO = listCategoryBook.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Get book ID from intent
        String idCategoryBook = getIntent().getStringExtra("idBook");
        if (idCategoryBook != null) {
            bookDAO = new BookDAO(this);
            bookDTO = bookDAO.getBookByID(Integer.parseInt(idCategoryBook));

            binding.edtIdBookEdit.setText(String.valueOf(bookDTO.getIdBook()));
            binding.edtNameBookEdit.setText(bookDTO.getName());
            binding.edtRentPriceEdit.setText(String.valueOf(bookDTO.getRentalFee()));

            categoryBookDAO = new CategoryBookDAO(this);
            categoryBookDTO = categoryBookDAO.getCategoryBookById(bookDTO.getCategory());

            int selectedPosition = 0;
            for (CategoryBookDTO cb : listCategoryBook) {
                if (cb.getId() == bookDTO.getIdBook())
                    break;
                selectedPosition++;
            }
            if (selectedPosition >= 0) {
                binding.spinnerEditBookCategory.setSelection(selectedPosition);
            }
        }

        binding.edtIdBookEdit.setOnClickListener(v ->
                Toast.makeText(this, "Không thể thay đổi mã sách!", Toast.LENGTH_SHORT).show()
        );

        binding.btnCancelEditBook.setOnClickListener(v -> finish());

        binding.btnEditBook.setOnClickListener(v -> {
            String idBookStr = binding.edtIdBookEdit.getText().toString();
            String nameBook = binding.edtNameBookEdit.getText().toString();
            String rentalFeeStr = binding.edtRentPriceEdit.getText().toString();

            if (nameBook.isEmpty()) {
                binding.edtNameBookEdit.setError("Tên sách không được để trống");
                return;
            }

            if (binding.spinnerEditBookCategory.getSelectedItem() == null) {
                // Spinner doesn’t support setError, could consider a Toast or custom validation UI
                return;
            }

            if (rentalFeeStr.isEmpty()) {
                binding.edtRentPriceEdit.setError("Giá thuê không được để trống");
                return;
            }

            int rentalFee = Integer.parseInt(rentalFeeStr);
            if (rentalFee < 0) {
                binding.edtRentPriceEdit.setError("Giá thuê không được nhỏ hơn 0");
                return;
            }

            bookDAO = new BookDAO(this);
            BookDTO updatedBook = new BookDTO(
                    Integer.parseInt(idBookStr),
                    nameBook,
                    rentalFee,
                    categoryBookDTO.getId(),
                    -1
            );

            int result = bookDAO.updateBook(updatedBook);
            if (result > 0) {
                androidx.appcompat.app.AlertDialog.Builder builderSuccess =
                        new androidx.appcompat.app.AlertDialog.Builder(this, R.style.CustomDialog);

                DialogLoginSuccessBinding bindingSuccess =
                        DialogLoginSuccessBinding.inflate(getLayoutInflater());

                builderSuccess.setView(bindingSuccess.getRoot());
                final androidx.appcompat.app.AlertDialog dialogSuccess = builderSuccess.create();
                dialogSuccess.show();
                dialogSuccess.setCancelable(false);

                bindingSuccess.txtLoginSuccess.setText("Sửa sách thành công");
                bindingSuccess.btnLoginSuccess.setOnClickListener(view -> {
                    Intent intent = new Intent(EditBookActivity.this, MainActivity.class);
                    intent.putExtra("ok", "bookOK");
                    startActivity(intent);
                    dialogSuccess.dismiss();
                    finish();
                });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

package com.librarymanager_n10.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.librarymanager_n10.databinding.ItemCategoryAddBookBinding;
import com.librarymanager_n10.dto.CategoryBookDTO;

import java.util.ArrayList;

public class CategoryAddBookAdapter extends ArrayAdapter<CategoryBookDTO> {

    public CategoryAddBookAdapter(Context context, ArrayList<CategoryBookDTO> listCategory) {
        super(context, 0, listCategory);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return initView(position, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return initView(position, parent);
    }

    private View initView(int position, ViewGroup parent) {
        ItemCategoryAddBookBinding binding = ItemCategoryAddBookBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);

        CategoryBookDTO category = getItem(position);
        if (category != null) {
            binding.txtItemCategoryBookName.setText(category.getName());
        }

        return binding.getRoot();
    }
}

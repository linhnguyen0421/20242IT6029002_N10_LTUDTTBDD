package com.librarymanager_n10.fragment.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.librarymanager_n10.adapter.CategoryBooksAdapter;
import com.librarymanager_n10.dao.CategoryBookDAO;
import com.librarymanager_n10.databinding.FragmentManagerCategoryBooksBinding;
import com.librarymanager_n10.dto.CategoryBookDTO;
import com.librarymanager_n10.ui.manager.AddCategoryBooksActivity;
import com.librarymanager_n10.viewmodel.SharedViewModel;

import java.util.ArrayList;

public class ManagerCategoryBooksFragment extends Fragment {

    private FragmentManagerCategoryBooksBinding binding;
    private CategoryBooksAdapter adapter;
    private ArrayList<CategoryBookDTO> listCategoryBooks;
    private CategoryBookDAO categoryBookDAO;
    private SharedViewModel sharedViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentManagerCategoryBooksBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.managerCategoryRecyclerView.setHasFixedSize(true);
        binding.managerCategoryRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        categoryBookDAO = new CategoryBookDAO(requireContext());
        listCategoryBooks = categoryBookDAO.getAllCategoryBooks();

        if (!listCategoryBooks.isEmpty()) {
            adapter = new CategoryBooksAdapter(requireContext(), listCategoryBooks);
            binding.managerCategoryRecyclerView.setAdapter(adapter);
            binding.managerCategoryRecyclerView.setVisibility(View.VISIBLE);
            adapter.notifyDataSetChanged();
        }

        String data = getArguments() != null ? getArguments().getString("ok") : null;
        if ("category".equals(data)) {
            refreshList();
        }

        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        sharedViewModel.getSearchText().observe(getViewLifecycleOwner(), newText -> {
            ArrayList<CategoryBookDTO> filterList = new ArrayList<>();
            for (CategoryBookDTO category : listCategoryBooks) {
                if (category.getName().toLowerCase().contains(newText.toLowerCase())) {
                    filterList.add(category);
                }
            }

            CategoryBooksAdapter filteredAdapter = new CategoryBooksAdapter(requireContext(), filterList);
            binding.managerCategoryRecyclerView.setAdapter(filteredAdapter);
            filteredAdapter.notifyDataSetChanged();
        });

        binding.fabAddCategory.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AddCategoryBooksActivity.class);
            startActivity(intent);
        });
    }

    private void refreshList() {
        listCategoryBooks.clear();
        listCategoryBooks = categoryBookDAO.getAllCategoryBooks();
        CategoryBooksAdapter refreshedAdapter = new CategoryBooksAdapter(requireContext(), listCategoryBooks);
        binding.managerCategoryRecyclerView.setAdapter(refreshedAdapter);
        refreshedAdapter.notifyDataSetChanged();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

package com.librarymanager_n10.fragment.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.librarymanager_n10.adapter.BillsAdapter;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.databinding.FragmentManagerBillsBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.dto.LibraryLoanSlipDTO;
import com.librarymanager_n10.ui.manager.AddLoanActivity;
import com.librarymanager_n10.viewmodel.SharedViewModel;

import java.util.ArrayList;

public class ManagerBillsFragment extends Fragment {

    private FragmentManagerBillsBinding binding;
    private LibraryLoanSlipDAO libraryLoanSlipDAO;
    private ArrayList<LibraryLoanSlipDTO> listLoanSlip;
    private BillsAdapter adapter;
    private SharedViewModel sharedViewModel;
    private BookDAO bookDAO;
    private ArrayList<BookDTO> listBook;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentManagerBillsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        binding.managerBillsRecyclerView.setHasFixedSize(true);
        binding.managerBillsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        libraryLoanSlipDAO = new LibraryLoanSlipDAO(requireContext());
        listLoanSlip = libraryLoanSlipDAO.getAllLoanSlips();

        if (!listLoanSlip.isEmpty()) {
            adapter = new BillsAdapter(requireContext(), listLoanSlip);
            binding.managerBillsRecyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }

        String data = getArguments() != null ? getArguments().getString("ok") : null;
        if ("ok".equals(data)) {
            refreshList();
        }

        // Get all book IDs
        ArrayList<Integer> listBookIds = new ArrayList<>();
        for (LibraryLoanSlipDTO slip : listLoanSlip) {
            listBookIds.add(slip.getIdBook());
        }

        // Get all books from DB
        bookDAO = new BookDAO(requireContext());
        listBook = new ArrayList<>();
        for (int id : listBookIds) {
            BookDTO bookDTO = bookDAO.getBookByID(id);
            listBook.add(bookDTO);
        }

        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        sharedViewModel.getSearchText().observe(getViewLifecycleOwner(), newText -> {
            ArrayList<Integer> filteredBookIds = new ArrayList<>();
            ArrayList<LibraryLoanSlipDTO> filteredLoanSlips = new ArrayList<>();

            for (BookDTO book : listBook) {
                if (book.getName().toLowerCase().contains(newText.toLowerCase())) {
                    filteredBookIds.add(book.getIdBook());
                }
            }

            for (int id : filteredBookIds) {
                LibraryLoanSlipDTO slip = libraryLoanSlipDAO.getLibrarianByBookID(id);
                filteredLoanSlips.add(slip);
            }

            updateData(filteredLoanSlips);
            adapter.notifyDataSetChanged();
        });

        binding.fabAddBill.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AddLoanActivity.class);
            startActivity(intent);
        });
    }

    private void updateData(ArrayList<LibraryLoanSlipDTO> newList) {
        listLoanSlip.clear();
        listLoanSlip.addAll(newList);
    }

    private void refreshList() {
        listLoanSlip.clear();
        listLoanSlip.addAll(libraryLoanSlipDAO.getAllLoanSlips());
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}

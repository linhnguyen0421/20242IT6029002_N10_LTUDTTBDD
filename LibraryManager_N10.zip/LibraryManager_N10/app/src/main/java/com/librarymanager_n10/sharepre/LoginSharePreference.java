package com.librarymanager_n10.sharepre;

import android.content.Context;
import android.content.SharedPreferences;

import com.librarymanager_n10.dto.LibrarianDTO;

public class LoginSharePreference {

    private SharedPreferences sharedPreferences;

    public LoginSharePreference(Context context) {
        sharedPreferences = context.getSharedPreferences("Login", Context.MODE_PRIVATE);
    }

    public void saveLogin(LibrarianDTO librarianDTO) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("id", librarianDTO.getId());
        editor.putString("password", librarianDTO.getPassword());
        editor.putString("name", librarianDTO.getName());
        editor.putString("role", librarianDTO.getRole());
        editor.apply();
    }

    public void isRemember(boolean login) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("login", login);
        editor.apply();
    }

    public boolean getRemember() {
        return sharedPreferences.getBoolean("login", false);
    }

    public String getID() {
        return sharedPreferences.getString("id", "");
    }

    public String getPassword() {
        return sharedPreferences.getString("password", "");
    }

    public String getName() {
        return sharedPreferences.getString("name", "");
    }

    public void clearLogin() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

    public String getRole() {
        return sharedPreferences.getString("role", "");
    }

    // Clear all data of librarian
    public void clearLibrarian() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("id");
        editor.remove("password");
        editor.remove("name");
        editor.remove("role");
        editor.apply();
    }
}

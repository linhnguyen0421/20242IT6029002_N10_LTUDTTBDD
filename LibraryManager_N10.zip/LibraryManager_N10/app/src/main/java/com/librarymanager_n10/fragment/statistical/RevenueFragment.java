package com.librarymanager_n10.fragment.statistical;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;

import androidx.fragment.app.Fragment;

import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.databinding.FragmentRevenueBinding;

public class RevenueFragment extends Fragment {

    private int revenue = 0;
    private int revenueDate = 0;
    private String startDate = "";
    private String endDate = "";

    private LibraryLoanSlipDAO loanSlipDAO;
    private FragmentRevenueBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentRevenueBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        loanSlipDAO = new LibraryLoanSlipDAO(requireContext());
        revenue = loanSlipDAO.getRevenue();
        binding.tvTotalRevenue.setText(revenue + " vnđ");

        binding.edtFromDate.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext());
            datePickerDialog.setOnDateSetListener((DatePicker view1, int year, int month, int dayOfMonth) -> {
                startDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                if (!startDate.isEmpty()) {
                    binding.edtFromDate.setText(startDate);
                }
            });
            datePickerDialog.show();
        });

        binding.edtToDate.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext());
            datePickerDialog.setOnDateSetListener((DatePicker view12, int year, int month, int dayOfMonth) -> {
                endDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                if (!endDate.isEmpty()) {
                    binding.edtToDate.setText(endDate);
                }
            });
            datePickerDialog.show();
        });

        binding.btnStatistical.setOnClickListener(v -> {
            if (startDate.isEmpty()) {
                binding.tvErrorDate.setVisibility(View.VISIBLE);
                binding.tvErrorDate.setText("*Chưa chọn ngày bắt đầu");
                return;
            }

            if (endDate.isEmpty()) {
                binding.tvErrorDate.setVisibility(View.VISIBLE);
                binding.tvErrorDate.setText("*Chưa chọn ngày kết thúc");
                return;
            }

            binding.tvErrorDate.setVisibility(View.GONE);
            revenueDate = loanSlipDAO.getRevenueByDate(startDate, endDate);
            binding.tvTotalRevenueDate.setText(revenueDate + " vnđ");
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

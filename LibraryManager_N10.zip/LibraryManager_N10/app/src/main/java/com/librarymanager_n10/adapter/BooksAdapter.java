package com.librarymanager_n10.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.CategoryBookDAO;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.databinding.DialogConfirmBinding;
import com.librarymanager_n10.databinding.DialogDeleteCategoryBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.databinding.ItemBooksBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.fragment.manager.ManagerBooksFragment;
import com.librarymanager_n10.ui.MainActivity;
import com.librarymanager_n10.ui.manager.EditBookActivity;

import java.util.ArrayList;

public class BooksAdapter extends RecyclerView.Adapter<BooksAdapter.BooksViewHolder> {

    private final ArrayList<BookDTO> listBooks;
    private final BookDAO bookDAO;
    private final CategoryBookDAO categoryBookDAO;
    private final LibraryLoanSlipDAO libraryLoanSlipDAO;
    private final Context context;

    public BooksAdapter(Context context, ArrayList<BookDTO> listBooks) {
        this.context = context;
        this.listBooks = listBooks;
        this.bookDAO = new BookDAO(context);
        this.categoryBookDAO = new CategoryBookDAO(context);
        this.libraryLoanSlipDAO = new LibraryLoanSlipDAO(context);
    }

    @NonNull
    @Override
    public BooksViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ItemBooksBinding binding = ItemBooksBinding.inflate(inflater, parent, false);
        return new BooksViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull BooksViewHolder holder, int position) {
        BookDTO bookDTO = listBooks.get(position);
        holder.bind(bookDTO);
    }

    @Override
    public int getItemCount() {
        return listBooks.size();
    }

    public class BooksViewHolder extends RecyclerView.ViewHolder {
        private final ItemBooksBinding binding;

        public BooksViewHolder(ItemBooksBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(BookDTO bookDTO) {
            binding.cardBaseBook.setOnClickListener(v -> {
                if (binding.cardImageButtonBook.getVisibility() == View.GONE) {
                    binding.cardImageButtonBook.setVisibility(View.VISIBLE);
                } else {
                    binding.cardImageButtonBook.setVisibility(View.GONE);
                }
            });

            binding.txtBookIdManager.setText(context.getString(R.string.id_book) + bookDTO.getIdBook());
            binding.txtBookNameManager.setText(context.getString(R.string.book_name) + bookDTO.getName());
            binding.txtCategoryNameManager.setText(context.getString(R.string.category) + categoryBookDAO.getCategoryBookById(bookDTO.getCategory()));
            binding.txtRentPriceManager.setText(context.getString(R.string.rental_fee) + bookDTO.getRentalFee() + " VND");

            binding.btnDeleteBook.setOnClickListener(v -> {
                AlertDialog.Builder builderConfirm = new AlertDialog.Builder(context);
                DialogConfirmBinding confirmBinding = DialogConfirmBinding.inflate(LayoutInflater.from(context));
                builderConfirm.setView(confirmBinding.getRoot());
                AlertDialog dialogConfirm = builderConfirm.create();
                confirmBinding.txtLoginSuccess.setText("Bạn có chắc chắn muốn xóa sách \n viên này không?");
                confirmBinding.btnNo.setOnClickListener(v1 -> dialogConfirm.dismiss());
                confirmBinding.btnYes.setOnClickListener(v12 -> {
                    boolean result = libraryLoanSlipDAO.checkLoanSlipExistsByBookID(bookDTO.getIdBook());
                    if (result) {
                        dialogConfirm.dismiss();
                        AlertDialog.Builder builderError = new AlertDialog.Builder(context);
                        DialogDeleteCategoryBinding errorBinding = DialogDeleteCategoryBinding.inflate(LayoutInflater.from(context));
                        builderError.setView(errorBinding.getRoot());
                        AlertDialog dialogError = builderError.create();
                        errorBinding.txtDeleteError.setText("Không thể xóa sách này \n vì có người mượn sách này trong \n thư viện");
                        errorBinding.btnDeleteError.setOnClickListener(v2 -> dialogError.dismiss());
                        dialogError.show();
                    } else {
                        int resultDelete = bookDAO.deleteBookById(bookDTO.getIdBook());
                        if (resultDelete > 0) {
                            listBooks.remove(bookDTO);
                            ManagerBooksFragment fragment = new ManagerBooksFragment();
                            ((MainActivity) context).getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.nav_host_fragment, fragment)
                                    .commit();
                            dialogConfirm.dismiss();
                            AlertDialog.Builder builderSuccess = new AlertDialog.Builder(context);
                            DialogLoginSuccessBinding successBinding = DialogLoginSuccessBinding.inflate(LayoutInflater.from(context));
                            builderSuccess.setView(successBinding.getRoot());
                            AlertDialog dialogSuccess = builderSuccess.create();
                            successBinding.txtLoginSuccess.setText("Xóa sách thành công");
                            successBinding.btnLoginSuccess.setOnClickListener(v3 -> dialogSuccess.dismiss());
                            dialogSuccess.show();
                        }
                    }
                });
                dialogConfirm.show();
            });

            binding.btnEditBook.setOnClickListener(v -> {
                Intent intent = new Intent(context, EditBookActivity.class);
                intent.putExtra("idBook", String.valueOf(bookDTO.getIdBook()));
                context.startActivity(intent);
            });
        }
    }
}

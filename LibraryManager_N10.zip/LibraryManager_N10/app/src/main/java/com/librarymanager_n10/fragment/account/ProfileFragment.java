package com.librarymanager_n10.fragment.account;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.databinding.FragmentProfileBinding;
import com.librarymanager_n10.sharepre.LoginSharePreference;
import com.librarymanager_n10.ui.account.EditAccountActivity;

public class ProfileFragment extends Fragment {

    private FragmentProfileBinding binding;
    private LoginSharePreference userSharePreference;
    private LibraryLoanSlipDAO libraryLoanSlipDAO;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.cardEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), EditAccountActivity.class);
            startActivity(intent);
        });

        userSharePreference = new LoginSharePreference(requireContext());
        String username = userSharePreference.getID();
        String role = userSharePreference.getRole();
        String fullname = userSharePreference.getName();

        libraryLoanSlipDAO = new LibraryLoanSlipDAO(requireContext());

        binding.tvUsernameProfile.setText("@" + username);
        binding.tvNameProfile.setText(fullname);
        binding.tvRoleProfile.setText("Người dùng: " + role);
        binding.tvTotalBorrowedProfile.setText("Phiếu mượn đã tạo: " + (username != null
                ? String.valueOf(libraryLoanSlipDAO.getNumberOfLoanSlipByID(username))
                : "0"));

        binding.cardFeature.setOnClickListener(v -> {
            ChangePasswordFragment changePasswordFragment = new ChangePasswordFragment();
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.nav_host_fragment, changePasswordFragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        });
    }

    private void updateData() {
        userSharePreference = new LoginSharePreference(requireContext());
        String username = userSharePreference.getID();
        String role = userSharePreference.getRole();
        String fullname = userSharePreference.getName();

        libraryLoanSlipDAO = new LibraryLoanSlipDAO(requireContext());

        binding.tvUsernameProfile.setText("@" + username);
        binding.tvNameProfile.setText(fullname);
        binding.tvRoleProfile.setText("Người dùng: " + role);
        if (username != null) {
            int total = libraryLoanSlipDAO.getNumberOfLoanSlipByID(username);
            binding.tvTotalBorrowedProfile.setText("Phiếu mượn đã tạo: " + total);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        updateData();
    }
}

package com.librarymanager_n10.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.librarymanager_n10.database.ManagerBookDataBase;
import com.librarymanager_n10.dto.BookDTO;

import java.util.ArrayList;

public class BookDAO {

    private final ManagerBookDataBase db;

    public BookDAO(Context context) {
        db = new ManagerBookDataBase(context);
    }

    // Return BookDTO by ID
    public BookDTO getBookByID(int id) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Book WHERE bookID = ?";
        Cursor cursor = dbReadable.rawQuery(sql, new String[]{String.valueOf(id)});
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int idBook = cursor.getInt(0);
            String name = cursor.getString(1);
            int rentalFee = cursor.getInt(2);
            int category = cursor.getInt(3);
            BookDTO bookDTO = new BookDTO(idBook, name, rentalFee, category, 0);
            cursor.close();
            dbReadable.close();
            return bookDTO;
        }
        cursor.close();
        dbReadable.close();
        return new BookDTO(-1, "", -1, -1, 0);
    }

    // Get all books
    public ArrayList<BookDTO> getAllBook() {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Book";
        Cursor cursor = dbReadable.rawQuery(sql, null);
        ArrayList<BookDTO> listBook = new ArrayList<>();
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                int idBook = cursor.getInt(0);
                String name = cursor.getString(1);
                int rentalFee = cursor.getInt(2);
                int category = cursor.getInt(3);
                BookDTO bookDTO = new BookDTO(idBook, name, rentalFee, category);
                listBook.add(bookDTO);
                cursor.moveToNext();
            }
        }
        cursor.close();
        dbReadable.close();
        return listBook;
    }

    // Check if any book exists by category ID
    public boolean checkBookExistByIdCategory(int idCategory) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Book WHERE categoryID = ?";
        Cursor cursor = dbReadable.rawQuery(sql, new String[]{String.valueOf(idCategory)});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        dbReadable.close();
        return exists;
    }

    // Insert a new book
    public long insertBook(BookDTO bookDTO) {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("bookName", bookDTO.getName());
        values.put("rentalFee", bookDTO.getRentalFee());
        values.put("categoryID", bookDTO.getCategory());
        long result = dbWritable.insert("Book", null, values);
        dbWritable.close();
        return result;
    }

    // Delete book by ID
    public int deleteBookById(int id) {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        int result = dbWritable.delete("Book", "bookID = ?", new String[]{String.valueOf(id)});
        dbWritable.close();
        return result;
    }

    // Update existing book
    public int updateBook(BookDTO bookDTO) {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("bookName", bookDTO.getName());
        values.put("rentalFee", bookDTO.getRentalFee());
        values.put("categoryID", bookDTO.getCategory());
        int result = dbWritable.update("Book", values, "bookID = ?", new String[]{String.valueOf(bookDTO.getIdBook())});
        dbWritable.close();
        return result;
    }
}

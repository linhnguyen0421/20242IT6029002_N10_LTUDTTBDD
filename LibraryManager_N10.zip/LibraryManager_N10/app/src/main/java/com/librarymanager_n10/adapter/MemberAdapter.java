package com.librarymanager_n10.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.dao.MemberDAO;
import com.librarymanager_n10.databinding.DialogConfirmBinding;
import com.librarymanager_n10.databinding.DialogDeleteCategoryBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.databinding.ItemMemberBinding;
import com.librarymanager_n10.dto.MemberDTO;
import com.librarymanager_n10.fragment.manager.ManagerMembersFragment;
import com.librarymanager_n10.ui.MainActivity;
import com.librarymanager_n10.ui.manager.EditMemberActivity;

import java.util.ArrayList;

public class MemberAdapter extends RecyclerView.Adapter<MemberAdapter.MemberViewHolder> {

    private final Context context;
    private final ArrayList<MemberDTO> listMembers;
    private final MemberDAO memberDAO;
    private final LibraryLoanSlipDAO libraryLoanSlipDAO;

    public MemberAdapter(Context context, ArrayList<MemberDTO> listMembers) {
        this.context = context;
        this.listMembers = listMembers;
        this.memberDAO = new MemberDAO(context);
        this.libraryLoanSlipDAO = new LibraryLoanSlipDAO(context);
    }

    @NonNull
    @Override
    public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemMemberBinding binding = ItemMemberBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new MemberViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MemberViewHolder holder, int position) {
        holder.bind(listMembers.get(position), memberDAO, listMembers, libraryLoanSlipDAO);
    }

    @Override
    public int getItemCount() {
        return listMembers.size();
    }

    public static class MemberViewHolder extends RecyclerView.ViewHolder {
        private final ItemMemberBinding binding;

        public MemberViewHolder(ItemMemberBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(MemberDTO memberDTO, MemberDAO memberDAO, ArrayList<MemberDTO> listMembers, LibraryLoanSlipDAO libraryLoanSlipDAO) {
            binding.cardBaseMember.setOnClickListener(v -> {
                if (binding.cardImageButtonMember.getVisibility() == View.GONE) {
                    binding.cardImageButtonMember.setVisibility(View.VISIBLE);
                } else {
                    binding.cardImageButtonMember.setVisibility(View.GONE);
                }
            });

            binding.txtIdMember.setText("Mã thành viên: " + memberDTO.getId());
            binding.txtNameMember.setText("Tên: " + memberDTO.getName());
            binding.txtBirthMember.setText("Năm sinh: " + memberDTO.getBirthYear());

            binding.btnDeleteMember.setOnClickListener(v -> {
                AlertDialog.Builder builderConfirm = new AlertDialog.Builder(binding.getRoot().getContext());
                DialogConfirmBinding bindingConfirm = DialogConfirmBinding.inflate(LayoutInflater.from(binding.getRoot().getContext()));
                builderConfirm.setView(bindingConfirm.getRoot());
                AlertDialog dialogConfirm = builderConfirm.create();

                bindingConfirm.txtLoginSuccess.setText("Bạn có chắc chắn muốn xóa thành \n viên này không?");
                bindingConfirm.btnNo.setOnClickListener(v1 -> dialogConfirm.dismiss());

                bindingConfirm.btnYes.setOnClickListener(v2 -> {
                    boolean result = libraryLoanSlipDAO.checkLoanSlipExistsByMemberID(memberDTO.getId());
                    if (result) {
                        dialogConfirm.dismiss();
                        AlertDialog.Builder builderError = new AlertDialog.Builder(binding.getRoot().getContext());
                        DialogDeleteCategoryBinding bindingError = DialogDeleteCategoryBinding.inflate(LayoutInflater.from(binding.getRoot().getContext()));
                        builderError.setView(bindingError.getRoot());
                        AlertDialog dialogError = builderError.create();

                        bindingError.txtDeleteError.setText("Không thể xóa thành viên này \n vì có mượn sách trong thư viện");
                        bindingError.btnDeleteError.setOnClickListener(v3 -> dialogError.dismiss());
                        dialogError.show();
                    } else {
                        boolean resultDelete = memberDAO.deleteMember(memberDTO.getId());
                        if (resultDelete) {
                            listMembers.remove(memberDTO);

                            ManagerMembersFragment fragment = new ManagerMembersFragment();
                            MainActivity activity = (MainActivity) binding.getRoot().getContext();
                            activity.getSupportFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.nav_host_fragment, fragment)
                                    .commit();

                            dialogConfirm.dismiss();

                            AlertDialog.Builder builderSuccess = new AlertDialog.Builder(binding.getRoot().getContext());
                            DialogLoginSuccessBinding bindingSuccess = DialogLoginSuccessBinding.inflate(LayoutInflater.from(binding.getRoot().getContext()));
                            builderSuccess.setView(bindingSuccess.getRoot());
                            AlertDialog dialogSuccess = builderSuccess.create();

                            bindingSuccess.txtLoginSuccess.setText("Xóa thành viên thành công");
                            bindingSuccess.btnLoginSuccess.setOnClickListener(v4 -> dialogSuccess.dismiss());
                            dialogSuccess.show();
                        }
                    }
                });

                dialogConfirm.show();
            });

            binding.btnEditMember.setOnClickListener(v -> {
                Intent intent = new Intent(binding.getRoot().getContext(), EditMemberActivity.class);
                intent.putExtra("idMember", String.valueOf(memberDTO.getId()));
                binding.getRoot().getContext().startActivity(intent);
            });
        }
    }
}

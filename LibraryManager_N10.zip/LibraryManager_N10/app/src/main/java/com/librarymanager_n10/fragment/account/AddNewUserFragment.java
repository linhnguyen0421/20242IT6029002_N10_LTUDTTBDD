package com.librarymanager_n10.fragment.account;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.LibrarianDAO;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.databinding.DialogProccessingBinding;
import com.librarymanager_n10.databinding.FragmentAddNewUserBinding;
import com.librarymanager_n10.dto.LibrarianDTO;
import com.librarymanager_n10.sharepre.LoginSharePreference;

public class AddNewUserFragment extends Fragment {

    private FragmentAddNewUserBinding binding;
    private LoginSharePreference userSharePreference;
    private LibrarianDAO librarianDAO;
    private LibrarianDTO librarianDTO;
    private String role;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAddNewUserBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        userSharePreference = new LoginSharePreference(requireContext());
        String password = userSharePreference.getPassword();
        String roleUser = userSharePreference.getRole();

        if ("librarian".equals(roleUser)) {
            Toast.makeText(requireContext(), "Bạn không có quyền thêm người dùng", Toast.LENGTH_SHORT).show();
        } else {
            binding.imgAddUser.setImageResource(R.drawable.changepasswordlock);
            binding.txtAddUser.setText("Nhập mật khẩu để xác thực");

            binding.btnVerify.setOnClickListener(v -> {
                if (binding.edtPasswordVerify.getText().toString().trim().equals(password)) {
                    binding.linearlayoutAddUser.setVisibility(View.VISIBLE);
                    binding.linearVerify.setVisibility(View.GONE);
                    binding.edtPasswordVerify.setText("");
                    binding.imgAddUser.setImageResource(R.drawable.adduser);
                    binding.txtAddUser.setText("Thêm người dùng");
                } else {
                    binding.edtPasswordVerify.setError("Mật khẩu không đúng");
                }
            });

            binding.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
                if (checkedId == R.id.radio_admin) {
                    role = "admin";
                } else if (checkedId == R.id.radio_librarian) {
                    role = "librarian";
                }
            });

            binding.btnCancelAddUser.setOnClickListener(v -> {
                binding.linearlayoutAddUser.setVisibility(View.GONE);
                binding.linearVerify.setVisibility(View.VISIBLE);
                binding.imgAddUser.setImageResource(R.drawable.changepasswordlock);
                binding.txtAddUser.setText("Nhập mật khẩu để xác thực");
            });

            binding.btnSaveAddUser.setOnClickListener(v -> {
                String usernameNew = binding.edtAddUser.getText().toString().trim();
                String passwordNew = binding.edtPassword.getText().toString().trim();
                String nameNew = binding.edtAddFullname.getText().toString().trim();
                String passwordConfirm = binding.edtPasswordConfirm.getText().toString().trim();

                if (usernameNew.isEmpty()) {
                    binding.edtAddUser.setError("Nhập username");
                    return;
                }

                librarianDAO = new LibrarianDAO(requireContext());
                if (librarianDAO.checkUsernameExist(usernameNew)) {
                    binding.edtAddUser.setError("Username đã tồn tại");
                    return;
                }

                if (!usernameNew.matches("^[a-zA-Z0-9_-]*$")) {
                    binding.edtAddUser.setError("Username chỉ có chữ và số + _ và -");
                    return;
                }

                if (nameNew.isEmpty()) {
                    binding.edtAddFullname.setError("Nhập họ tên");
                    return;
                }

                if (passwordNew.isEmpty() || passwordNew.length() < 6) {
                    binding.edtPassword.setError("Mật khẩu phải lớn hơn 6 ký tự");
                    return;
                }

                if (passwordConfirm.isEmpty() || !passwordNew.equals(passwordConfirm)) {
                    binding.edtPasswordConfirm.setError("Mật khẩu không trùng khớp");
                    return;
                }

                librarianDTO = new LibrarianDTO(usernameNew, nameNew, passwordNew, role);

                if ("librarian".equals(roleUser)) {
                    Toast.makeText(requireContext(), "Bạn không có quyền thêm người dùng", Toast.LENGTH_SHORT).show();
                } else {
                    long result = librarianDAO.insertLibrarian(librarianDTO);
                    if (result > 0) {
                        showProcessingDialog("Đang thêm người dùng");

                        new Handler().postDelayed(() -> {
                            showSuccessDialog("Thêm người dùng thành công");
                        }, 1000);
                    } else {
                        showErrorDialog("Thêm người dùng thất bại");
                    }
                }
            });
        }
    }

    private void showProcessingDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext(), R.style.CustomDialog);
        DialogProccessingBinding bindingDialog = DialogProccessingBinding.inflate(getLayoutInflater());
        builder.setView(bindingDialog.getRoot());
        bindingDialog.textViewLoading.setText(message);
        builder.setCancelable(false);
        builder.create().show();
    }

    private void showSuccessDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext(), R.style.CustomDialog);
        DialogLoginSuccessBinding bindingDialog = DialogLoginSuccessBinding.inflate(getLayoutInflater());
        builder.setView(bindingDialog.getRoot());
        bindingDialog.txtLoginSuccess.setText(message);
        builder.create().show();
    }

    private void showErrorDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext(), R.style.CustomDialog);
        DialogLoginSuccessBinding bindingDialog = DialogLoginSuccessBinding.inflate(getLayoutInflater());
        builder.setView(bindingDialog.getRoot());
        bindingDialog.txtLoginSuccess.setText(message);
        bindingDialog.imgSuccess.setImageResource(R.drawable.error);
        builder.create().show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

package com.librarymanager_n10.adapter;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.librarymanager_n10.databinding.ItemBooksLoanBinding;
import com.librarymanager_n10.dto.BookDTO;

import java.util.ArrayList;

public class BookLoanAdapter extends ArrayAdapter<BookDTO> {

    private final LayoutInflater inflater;

    public BookLoanAdapter(@NonNull Context context, ArrayList<BookDTO> listBooks) {
        super(context, 0, listBooks);
        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, parent);
    }

    @NonNull
    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, parent);
    }

    private View initView(int position, ViewGroup parent) {
        ItemBooksLoanBinding binding = ItemBooksLoanBinding.inflate(inflater, parent, false);

        BookDTO book = getItem(position);
        if (book != null) {
            binding.txtItemBookName.setText(book.getName());
        }

        return binding.getRoot();
    }
}

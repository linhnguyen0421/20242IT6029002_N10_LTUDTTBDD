package com.librarymanager_n10.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import com.librarymanager_n10.ui.manager.EditCategoryBookActivity;
import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.CategoryBookDAO;
import com.librarymanager_n10.databinding.DialogConfirmBinding;
import com.librarymanager_n10.databinding.DialogDeleteCategoryBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.databinding.ItemCategoryBinding;
import com.librarymanager_n10.dto.CategoryBookDTO;
import com.librarymanager_n10.fragment.manager.ManagerCategoryBooksFragment;
import com.librarymanager_n10.ui.MainActivity;

import java.util.ArrayList;
import java.util.List;

public class CategoryBooksAdapter extends RecyclerView.Adapter<CategoryBooksAdapter.CategoryBooksViewHolder> {

    private final List<CategoryBookDTO> listCategoryBooks;
    private final CategoryBookDAO categoryBookDAO;
    private final BookDAO bookDAO;

    public CategoryBooksAdapter(Context context, ArrayList<CategoryBookDTO> listCategoryBooks) {
        this.listCategoryBooks = listCategoryBooks;
        this.categoryBookDAO = new CategoryBookDAO(context);
        this.bookDAO = new BookDAO(context);
    }

    public static class CategoryBooksViewHolder extends RecyclerView.ViewHolder {
        private final ItemCategoryBinding binding;

        public CategoryBooksViewHolder(ItemCategoryBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(CategoryBookDTO categoryBook, CategoryBookDAO categoryBookDAO, List<CategoryBookDTO> listCategoryBooks, BookDAO bookDAO) {
            binding.cardBaseCategory.setOnClickListener(v -> {
                if (binding.cardImageButtonCategory.getVisibility() == View.GONE) {
                    binding.cardImageButtonCategory.setVisibility(View.VISIBLE);
                } else {
                    binding.cardImageButtonCategory.setVisibility(View.GONE);
                }
            });

            binding.txtCategoryID.setText("Mã loại sách: " + categoryBook.getId());
            binding.txtCategoryName.setText("Tên loại sách: " + categoryBook.getName());

            binding.btnDeleteCategory.setOnClickListener(v -> {
                AlertDialog.Builder builderConfirm = new AlertDialog.Builder(binding.getRoot().getContext());
                DialogConfirmBinding bindingConfirm = DialogConfirmBinding.inflate(LayoutInflater.from(binding.getRoot().getContext()));
                builderConfirm.setView(bindingConfirm.getRoot());
                AlertDialog dialogConfirm = builderConfirm.create();

                bindingConfirm.btnNo.setOnClickListener(view -> dialogConfirm.dismiss());
                bindingConfirm.btnYes.setOnClickListener(view -> {
                    boolean result = bookDAO.checkBookExistByIdCategory(categoryBook.getId());
                    if (result) {
                        dialogConfirm.dismiss();
                        AlertDialog.Builder builderError = new AlertDialog.Builder(binding.getRoot().getContext());
                        DialogDeleteCategoryBinding bindingError = DialogDeleteCategoryBinding.inflate(LayoutInflater.from(binding.getRoot().getContext()));
                        builderError.setView(bindingError.getRoot());
                        AlertDialog dialogError = builderError.create();
                        bindingError.btnDeleteError.setOnClickListener(view1 -> dialogError.dismiss());
                        dialogError.show();
                    } else {
                        AlertDialog.Builder builderLoading = new AlertDialog.Builder(binding.getRoot().getContext());
                        LayoutInflater inflaterLoading = LayoutInflater.from(binding.getRoot().getContext());
                        builderLoading.setView(inflaterLoading.inflate(R.layout.dialog_proccessing, null));
                        builderLoading.setCancelable(false);
                        AlertDialog dialogLoading = builderLoading.create();
                        dialogLoading.show();

                        int deleteResult = categoryBookDAO.deleteCategoryBook(categoryBook.getId());
                        if (deleteResult > 0) {
                            listCategoryBooks.remove(categoryBook);

                            ManagerCategoryBooksFragment fragment = new ManagerCategoryBooksFragment();
                            FragmentManager fragmentManagerCategory = ((MainActivity) binding.getRoot().getContext()).getSupportFragmentManager();
                            fragmentManagerCategory.beginTransaction().replace(R.id.nav_host_fragment, fragment).commit();

                            dialogConfirm.dismiss();
                            dialogLoading.dismiss();

                            AlertDialog.Builder builderSuccess = new AlertDialog.Builder(binding.getRoot().getContext());
                            DialogLoginSuccessBinding bindingSuccess = DialogLoginSuccessBinding.inflate(LayoutInflater.from(binding.getRoot().getContext()));
                            builderSuccess.setView(bindingSuccess.getRoot());
                            AlertDialog dialogSuccess = builderSuccess.create();
                            bindingSuccess.txtLoginSuccess.setText("Xóa loại sách thành công");
                            bindingSuccess.btnLoginSuccess.setOnClickListener(view12 -> dialogSuccess.dismiss());
                            dialogSuccess.show();
                        }
                    }
                });
                dialogConfirm.show();
            });

            binding.btnEditCategory.setOnClickListener(v -> {
                Intent intent = new Intent(binding.getRoot().getContext(), EditCategoryBookActivity.class);
                intent.putExtra("idCategory", String.valueOf(categoryBook.getId()));
                binding.getRoot().getContext().startActivity(intent);
            });
        }
    }

    @Override
    public CategoryBooksViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ItemCategoryBinding binding = ItemCategoryBinding.inflate(inflater, parent, false);
        return new CategoryBooksViewHolder(binding);
    }

    @Override
    public int getItemCount() {
        return listCategoryBooks.size();
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryBooksViewHolder holder, int position) {
        CategoryBookDTO categoryBook = listCategoryBooks.get(position);
        holder.bind(categoryBook, categoryBookDAO, listCategoryBooks, bookDAO);
    }
}

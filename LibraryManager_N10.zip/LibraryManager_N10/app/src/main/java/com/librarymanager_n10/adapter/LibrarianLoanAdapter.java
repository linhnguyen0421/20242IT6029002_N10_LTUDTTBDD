package com.librarymanager_n10.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.librarymanager_n10.databinding.ItemLibrianLoanBinding;
import com.librarymanager_n10.dto.LibrarianDTO;

import java.util.ArrayList;

public class LibrarianLoanAdapter extends ArrayAdapter<LibrarianDTO> {

    private final Context context;

    public LibrarianLoanAdapter(@NonNull Context context, @NonNull ArrayList<LibrarianDTO> listLibrarian) {
        super(context, 0, listLibrarian);
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, parent);
    }

    @NonNull
    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, parent);
    }

    private View initView(int position, ViewGroup parent) {
        ItemLibrianLoanBinding binding = ItemLibrianLoanBinding.inflate(LayoutInflater.from(context), parent, false);

        LibrarianDTO librarian = getItem(position);
        if (librarian != null) {
            binding.txtItemLibrarianName.setText(librarian.getName());
        }

        return binding.getRoot();
    }
}

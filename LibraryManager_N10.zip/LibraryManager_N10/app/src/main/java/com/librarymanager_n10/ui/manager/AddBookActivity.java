package com.librarymanager_n10.ui.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.adapter.CategoryAddBookAdapter;
import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.CategoryBookDAO;
import com.librarymanager_n10.databinding.ActivityAddBookBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.dto.CategoryBookDTO;
import com.librarymanager_n10.ui.MainActivity;

import java.util.ArrayList;

public class AddBookActivity extends AppCompatActivity {

    private ActivityAddBookBinding binding;
    private CategoryBookDAO categoryBookDAO;
    private CategoryBookDTO categoryBookDTO;
    private BookDAO bookDAO;
    private BookDTO bookDTO;
    private ArrayList<CategoryBookDTO> listCategoryBook;
    private CategoryAddBookAdapter categoryLoanAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddBookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbarAddBook);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Get all category books
        categoryBookDAO = new CategoryBookDAO(this);
        listCategoryBook = categoryBookDAO.getAllCategoryBooks();

        // Set adapter for spinner
        categoryLoanAdapter = new CategoryAddBookAdapter(this, listCategoryBook);
        binding.spinnerAddBookCategory.setAdapter(categoryLoanAdapter);

        // Set event for spinner
        binding.spinnerAddBookCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int positionCategory, long id) {
                categoryBookDTO = listCategoryBook.get(positionCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        binding.btnCancelAddBook.setOnClickListener(v -> finish());

        binding.btnAddBook.setOnClickListener(v -> {
            String name = binding.edtNameBook.getText().toString();
            String rentalPrice = binding.edtRentPrice.getText().toString();

            if (name.isEmpty()) {
                binding.edtNameBook.setError("Tên sách không được để trống");
                return;
            }

            if (binding.spinnerAddBookCategory.getSelectedItem() == null) {
                binding.spinnerAddBookCategory.setErrorText("Please choose category book");
                Toast.makeText(this, "Please choose book", Toast.LENGTH_SHORT).show();
                return;
            } else {
                binding.spinnerAddBookCategory.setErrorText("");
            }

            if (rentalPrice.isEmpty()) {
                binding.edtRentPrice.setError("Giá thuê không được để trống");
                return;
            }

            if (Integer.parseInt(rentalPrice) < 0) {
                binding.edtRentPrice.setError("Giá thuê không được nhỏ hơn 0");
                return;
            }

            int categoryBook = categoryBookDTO.getId();

            bookDAO = new BookDAO(this);
            bookDTO = new BookDTO(-1, name, Integer.parseInt(rentalPrice), categoryBook);
            long result = bookDAO.insertBook(bookDTO);
            if (result > 0) {
                androidx.appcompat.app.AlertDialog.Builder builderSuccess = new androidx.appcompat.app.AlertDialog.Builder(this, R.style.CustomDialog);
                com.librarymanager_n10.databinding.DialogLoginSuccessBinding bindingSuccess =
                        com.librarymanager_n10.databinding.DialogLoginSuccessBinding.inflate(getLayoutInflater());

                builderSuccess.setView(bindingSuccess.getRoot());
                androidx.appcompat.app.AlertDialog dialogSuccess = builderSuccess.create();
                dialogSuccess.setCancelable(false);
                dialogSuccess.show();
                bindingSuccess.txtLoginSuccess.setText("Thêm thành công sách!");
                bindingSuccess.btnLoginSuccess.setOnClickListener(v1 -> {
                    dialogSuccess.dismiss();
                    Intent intent = new Intent(AddBookActivity.this, MainActivity.class);
                    intent.putExtra("ok", "bookOK");
                    startActivity(intent);
                    finish();
                });

            } else {
                Toast.makeText(this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

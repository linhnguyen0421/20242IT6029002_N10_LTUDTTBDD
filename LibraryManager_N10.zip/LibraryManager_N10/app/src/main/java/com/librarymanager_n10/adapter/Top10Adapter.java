package com.librarymanager_n10.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.librarymanager_n10.dao.CategoryBookDAO;
import com.librarymanager_n10.databinding.ItemTop10Binding;
import com.librarymanager_n10.dto.BookDTO;

import java.util.ArrayList;

public class Top10Adapter extends RecyclerView.Adapter<Top10Adapter.Top10ViewHolder> {
    private final Context context;
    private final ArrayList<BookDTO> listTop10;
    private final CategoryBookDAO categoryBookDAO;

    public Top10Adapter(Context context, ArrayList<BookDTO> listTop10) {
        this.context = context;
        this.listTop10 = listTop10;
        this.categoryBookDAO = new CategoryBookDAO(context);
    }

    public static class Top10ViewHolder extends RecyclerView.ViewHolder {
        private final ItemTop10Binding binding;

        public Top10ViewHolder(ItemTop10Binding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(BookDTO book, CategoryBookDAO categoryBookDAO) {
            // Assuming BookDTO has 'idBook', 'name', 'rentalFee', and 'timeRental' fields
            // Assuming BookDTO has 'idBook', 'name', 'rentalFee', and 'timeRental' fields
            binding.txtBookIdManagerTop10.setText("Mã sách: " + book.getIdBook());
            binding.txtBookNameManagerTop10.setText("Tên sách: " + book.getName());
            binding.txtRentPriceManager.setText("Giá thuê: " + book.getRentalFee() + " VND");
            binding.txtTimesRented.setText("Số lần mượn: " + book.getTimeRental());
            // Get category name by ID
            binding.txtCategoryNameManagerTop10.setText("Thể loại: " + categoryBookDAO.getNameCategoryBookById(book.getCategory()));
        }
    }

    @Override
    public Top10ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ItemTop10Binding binding = ItemTop10Binding.inflate(inflater, parent, false);
        return new Top10ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(Top10ViewHolder holder, int position) {
        BookDTO book = listTop10.get(position);
        holder.bind(book, categoryBookDAO);
    }

    @Override
    public int getItemCount() {
        return listTop10.size();
    }
}

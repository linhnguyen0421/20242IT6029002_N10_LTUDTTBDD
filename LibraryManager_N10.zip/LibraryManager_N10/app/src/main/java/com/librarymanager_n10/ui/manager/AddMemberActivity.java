package com.librarymanager_n10.ui.manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.MemberDAO;
import com.librarymanager_n10.databinding.ActivityAddMemberBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.dto.MemberDTO;
import com.librarymanager_n10.ui.MainActivity;

public class AddMemberActivity extends AppCompatActivity {

    private ActivityAddMemberBinding binding;
    private MemberDAO memberDAO;
    private MemberDTO memberDTO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddMemberBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbarAddMember);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.btnCancelAddMember.setOnClickListener(v -> finish());

        binding.btnSaveAddMember.setOnClickListener(v -> {
            String name = binding.edtNameMember.getText().toString();
            String birthYear = binding.edtBirthMember.getText().toString();

            if (name.isEmpty()) {
                binding.edtNameMember.setError("Tên không được để trống");
                return;
            }

            if (birthYear.isEmpty()) {
                binding.edtBirthMember.setError("Năm sinh không được để trống");
                return;
            }

            try {
                int year = Integer.parseInt(birthYear);
                if (year < 1900 || year > 2016) {
                    binding.edtBirthMember.setError("Năm sinh không hợp lệ");
                    return;
                }
            } catch (NumberFormatException e) {
                binding.edtBirthMember.setError("Năm sinh phải là số");
                return;
            }

            memberDAO = new MemberDAO(this);
            memberDTO = new MemberDTO(-1, name, birthYear);
            long result = memberDAO.insertMember(memberDTO);

            if (result > 0) {
                AlertDialog.Builder builderSuccess = new AlertDialog.Builder(this, R.style.CustomDialog);
                DialogLoginSuccessBinding bindingSuccess = DialogLoginSuccessBinding.inflate(getLayoutInflater());
                builderSuccess.setView(bindingSuccess.getRoot());
                AlertDialog dialogSuccess = builderSuccess.create();
                dialogSuccess.setCancelable(false);
                dialogSuccess.show();

                bindingSuccess.txtLoginSuccess.setText("Thêm thành công thành viên!");
                bindingSuccess.btnLoginSuccess.setOnClickListener(view -> {
                    dialogSuccess.dismiss();
                    Intent intent = new Intent(this, MainActivity.class);
                    intent.putExtra("ok", "member");
                    startActivity(intent);
                    finish();
                });

            } else {
                Toast.makeText(this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

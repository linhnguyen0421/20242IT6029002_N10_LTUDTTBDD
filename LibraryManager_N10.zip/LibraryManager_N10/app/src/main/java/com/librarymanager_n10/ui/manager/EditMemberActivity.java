package com.librarymanager_n10.ui.manager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.MemberDAO;
import com.librarymanager_n10.databinding.ActivityEditMemberBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.dto.MemberDTO;
import com.librarymanager_n10.ui.MainActivity;

public class EditMemberActivity extends AppCompatActivity {
    private ActivityEditMemberBinding binding;
    private MemberDAO memberDAO;
    private MemberDTO memberDTO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditMemberBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        setSupportActionBar(binding.toolbarEditMember);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        String idMemberStr = getIntent().getStringExtra("idMember");

        if (idMemberStr != null) {
            memberDAO = new MemberDAO(this);
            memberDTO = memberDAO.getMemberDTOById(Integer.parseInt(idMemberStr));
            Log.d("MemberDTO", "MemberDTO: " + memberDTO.toString());

            binding.edtIdMember.setText(String.valueOf(memberDTO.getId()));
            binding.edtNameMember.setText(memberDTO.getName());
            binding.edtBirthMemberEdit.setText(memberDTO.getBirthYear());
        }

        binding.edtIdMember.setOnClickListener(v ->
                Toast.makeText(this, "Không thể thay đổi mã thành viên!", Toast.LENGTH_SHORT).show()
        );

        binding.btnCancelEditMember.setOnClickListener(v -> finish());

        binding.btnSaveEditMember.setOnClickListener(v -> {
            String idMember = binding.edtIdMember.getText().toString();
            String nameMember = binding.edtNameMember.getText().toString();
            String birthMember = binding.edtBirthMemberEdit.getText().toString();

            if (nameMember.isEmpty()) {
                binding.edtNameMember.setError("Tên thành viên không được để trống");
                return;
            }

            if (birthMember.isEmpty()) {
                binding.edtBirthMemberEdit.setError("Năm sinh không được để trống");
                return;
            }

            int birthYear = Integer.parseInt(birthMember);
            if (birthYear < 1900 || birthYear > 2021) {
                binding.edtBirthMemberEdit.setError("Năm sinh không hợp lệ");
                return;
            }

            memberDAO = new MemberDAO(this);
            memberDTO = new MemberDTO(Integer.parseInt(idMember), nameMember, birthMember);
            int result = memberDAO.updateMember(memberDTO);

            if (result > 0) {
                AlertDialog.Builder builderSuccess = new AlertDialog.Builder(this, R.style.CustomDialog);
                DialogLoginSuccessBinding bindingSuccess = DialogLoginSuccessBinding.inflate(getLayoutInflater());
                builderSuccess.setView(bindingSuccess.getRoot());
                AlertDialog dialogSuccess = builderSuccess.create();
                dialogSuccess.show();
                bindingSuccess.txtLoginSuccess.setText("Sửa thành viên thành công");
                bindingSuccess.btnLoginSuccess.setOnClickListener(btn -> {
                    dialogSuccess.dismiss();
                    Intent mainIntent = new Intent(EditMemberActivity.this, MainActivity.class);
                    mainIntent.putExtra("ok", "member");
                    startActivity(mainIntent);
                    finish();
                });
            } else {
                Toast.makeText(this, "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

package com.librarymanager_n10.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.librarymanager_n10.database.ManagerBookDataBase;
import com.librarymanager_n10.dto.MemberDTO;

import java.util.ArrayList;

public class MemberDAO {
    private final ManagerBookDataBase db;

    public MemberDAO(Context context) {
        db = new ManagerBookDataBase(context);
    }

    // Get MemberDTO by ID
    public MemberDTO getMemberDTOById(int id) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Member WHERE memberID = ?";
        Cursor cursor = dbReadable.rawQuery(sql, new String[]{String.valueOf(id)});
        MemberDTO memberDTO = new MemberDTO(-1, "", "");

        if (cursor.moveToFirst()) {
            int idMember = cursor.getInt(0);
            String name = cursor.getString(1);
            String birthYear = cursor.getString(2);
            memberDTO = new MemberDTO(idMember, name, birthYear);
        }

        cursor.close();
        dbReadable.close();
        return memberDTO;
    }

    // Get all members
    public ArrayList<MemberDTO> getAllMember() {
        ArrayList<MemberDTO> listMember = new ArrayList<>();
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Member";
        Cursor cursor = dbReadable.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do {
                int idMember = cursor.getInt(0);
                String name = cursor.getString(1);
                String birthYear = cursor.getString(2);
                MemberDTO memberDTO = new MemberDTO(idMember, name, birthYear);
                listMember.add(memberDTO);
            } while (cursor.moveToNext());
        }

        cursor.close();
        dbReadable.close();
        return listMember;
    }

    // Insert member
    public long insertMember(MemberDTO memberDTO) {
        long result = -1;
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("memberName", memberDTO.getName());
        values.put("birthYear", memberDTO.getBirthYear());

        try {
            result = dbWritable.insert("Member", null, values);
        } catch (Exception e) {
            e.printStackTrace();
        }

        dbWritable.close();
        return result;
    }

    // Delete member
    public boolean deleteMember(int id) {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        int result = dbWritable.delete("Member", "memberID = ?", new String[]{String.valueOf(id)});
        dbWritable.close();
        return result > 0;
    }

    // Update member
    public int updateMember(MemberDTO memberDTO) {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("memberName", memberDTO.getName());
        values.put("birthYear", memberDTO.getBirthYear());

        int result = dbWritable.update("Member", values, "memberID = ?", new String[]{String.valueOf(memberDTO.getId())});
        dbWritable.close();
        return result;
    }
}

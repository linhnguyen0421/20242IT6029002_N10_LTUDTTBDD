package com.librarymanager_n10.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.librarymanager_n10.database.ManagerBookDataBase;
import com.librarymanager_n10.dto.CategoryBookDTO;

import java.util.ArrayList;

public class CategoryBookDAO {

    private final ManagerBookDataBase db;

    public CategoryBookDAO(Context context) {
        db = new ManagerBookDataBase(context);
    }

    // Get all category books
    public ArrayList<CategoryBookDTO> getAllCategoryBooks() {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM CategoryBook";
        Cursor cursor = dbReadable.rawQuery(sql, null);
        ArrayList<CategoryBookDTO> list = new ArrayList<>();

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                int idCategory = cursor.getInt(0);
                String nameCategory = cursor.getString(1);
                CategoryBookDTO category = new CategoryBookDTO(idCategory, nameCategory);
                list.add(category);
                cursor.moveToNext();
            }
        }

        cursor.close();
        dbReadable.close();
        return list;
    }

    // Get name of category book by ID
    public String getNameCategoryBookById(int id) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM CategoryBook WHERE categoryID = " + id;
        Cursor cursor = dbReadable.rawQuery(sql, null);
        String nameCategory = "";

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                nameCategory = cursor.getString(1);
                cursor.moveToNext();
            }
        }

        cursor.close();
        dbReadable.close();
        return nameCategory;
    }

    // Get category by ID
    public CategoryBookDTO getCategoryBookById(int id) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM CategoryBook WHERE categoryID = " + id;
        Cursor cursor = dbReadable.rawQuery(sql, null);

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int idCategory = cursor.getInt(0);
            String nameCategory = cursor.getString(1);
            cursor.close();
            dbReadable.close();
            return new CategoryBookDTO(idCategory, nameCategory);
        }

        cursor.close();
        dbReadable.close();
        return new CategoryBookDTO(-1, "");
    }

    // Insert category book
    public long insertCategoryBook(CategoryBookDTO categoryBookDTO) {
        long result = -1;
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("categoryName", categoryBookDTO.getName());

        try {
            result = dbWritable.insert("CategoryBook", null, values);
        } catch (Exception e) {
            e.printStackTrace();
        }

        dbWritable.close();
        return result;
    }

    // Delete category book
    public int deleteCategoryBook(int id) {
        int result = -1;
        SQLiteDatabase dbWritable = db.getWritableDatabase();

        try {
            result = dbWritable.delete("CategoryBook", "categoryID = ?", new String[]{String.valueOf(id)});
        } catch (Exception e) {
            e.printStackTrace();
        }

        dbWritable.close();
        return result;
    }

    // Update category book
    public int updateCategoryBook(CategoryBookDTO categoryBookDTO) {
        int result = -1;
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("categoryName", categoryBookDTO.getName());

        try {
            result = dbWritable.update(
                    "CategoryBook",
                    values,
                    "categoryID = ?",
                    new String[]{String.valueOf(categoryBookDTO.getId())}
            );
        } catch (Exception e) {
            e.printStackTrace();
        }

        dbWritable.close();
        return result;
    }
}

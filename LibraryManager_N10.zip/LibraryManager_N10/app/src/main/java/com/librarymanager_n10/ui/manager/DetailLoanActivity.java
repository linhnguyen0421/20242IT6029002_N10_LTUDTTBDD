package com.librarymanager_n10.ui.manager;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.dao.BookDAO;
import com.librarymanager_n10.dao.CategoryBookDAO;
import com.librarymanager_n10.dao.LibrarianDAO;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.dao.MemberDAO;
import com.librarymanager_n10.databinding.ActivityDetailLoanBinding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.dto.CategoryBookDTO;
import com.librarymanager_n10.dto.LibrarianDTO;
import com.librarymanager_n10.dto.LibraryLoanSlipDTO;
import com.librarymanager_n10.dto.MemberDTO;

public class DetailLoanActivity extends AppCompatActivity {

    private ActivityDetailLoanBinding binding;
    private LibraryLoanSlipDAO loanSlipDAO;
    private BookDAO bookDAO;
    private BookDTO bookDTO;
    private CategoryBookDAO categoryBookDAO;
    private CategoryBookDTO categoryBookDTO;
    private MemberDAO memberDAO;
    private MemberDTO memberDTO;
    private LibrarianDAO librarianDAO;
    private LibrarianDTO librarianDTO;
    private LibraryLoanSlipDTO loanSlipDTO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailLoanBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbarDetailLoan);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Get ID from intent
        String idLoanSlip = getIntent().getStringExtra("idLoanSlip");

        if (idLoanSlip != null) {
            loanSlipDAO = new LibraryLoanSlipDAO(this);
            loanSlipDTO = loanSlipDAO.getLoanSlipByID(Integer.parseInt(idLoanSlip));

            memberDAO = new MemberDAO(this);
            memberDTO = memberDAO.getMemberDTOById(loanSlipDTO.getIdMember());

            librarianDAO = new LibrarianDAO(this);
            librarianDTO = librarianDAO.getLibrarianByID(loanSlipDTO.getIdLibrarian());

            bookDAO = new BookDAO(this);
            bookDTO = bookDAO.getBookByID(loanSlipDTO.getIdBook());

            categoryBookDAO = new CategoryBookDAO(this);
            categoryBookDTO = categoryBookDAO.getCategoryBookById(bookDTO.getCategory());
        }

        binding.tvIdBillDetail.setText("Mã phiếu mượn: " + loanSlipDTO.getId());
        binding.tvNameBookDetail.setText("Tên sách: " + bookDTO.getName());
        binding.tvCategoryBookDetail.setText("Loại sách: " + categoryBookDTO.getName());
        binding.tvPriceBookDetail.setText("Giá thuê: " + bookDTO.getRentalFee());
        binding.tvDateLoanDetail.setText("Ngày mượn: " + loanSlipDTO.getDateLoan());
        binding.tvNameUserDetail.setText("Tên thủ thư: " + librarianDTO.getName());
        binding.tvNameUserBorrowDetail.setText("Thành viên mượn: " + memberDTO.getName());

        String statusText = (loanSlipDTO.getStatus() == 0)
                ? "Trạng thái:  Chưa trả"
                : "Trạng thái: Đã trả";
        binding.tvStatusDetail.setText(statusText);

        binding.btnOkDetail.setOnClickListener(v -> finish());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

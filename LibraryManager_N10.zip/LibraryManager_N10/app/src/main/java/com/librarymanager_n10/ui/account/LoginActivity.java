package com.librarymanager_n10.ui.account;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.librarymanager_n10.R;
import com.librarymanager_n10.dao.LibrarianDAO;
import com.librarymanager_n10.databinding.ActivityLoginBinding;
import com.librarymanager_n10.databinding.DialogLoginSuccessBinding;
import com.librarymanager_n10.dto.LibrarianDTO;
import com.librarymanager_n10.sharepre.LoginSharePreference;
import com.librarymanager_n10.ui.MainActivity;

public class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding binding;
    private String username = "";
    private String password = "";

    private LibrarianDAO librarianDAO;
    private LoginSharePreference loginSharePreference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        loginSharePreference = new LoginSharePreference(this);
        if (loginSharePreference.getRemember()) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        }

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnLoginClick.setOnClickListener(v -> {
            if (binding.constraintLayout.getVisibility() == View.VISIBLE) {
                binding.constraintLayout.setVisibility(View.GONE);
            } else {
                binding.constraintLayout.setVisibility(View.VISIBLE);
                binding.btnLoginClick.setVisibility(View.GONE);
            }
        });

        binding.btnLogin.setOnClickListener(v -> {
            username = binding.edtUsername.getText().toString().trim();
            password = binding.edtPassword.getText().toString().trim();

            if (username.isEmpty()) {
                binding.edtUsername.setError("Nhập username");
                return;
            }

            librarianDAO = new LibrarianDAO(this);
            int result = librarianDAO.getLibrarianUsernameByID(username);

            if (result == -1) {
                binding.edtUsername.setError("Username sai");
                return;
            }

            if (password.isEmpty()) {
                binding.edtPassword.setError("Nhập mật khẩu");
                return;
            }

            result = librarianDAO.checkPasswordLibrarian(username, password);
            if (result == -1) {
                binding.edtPassword.setError("Mật khẩu sai");
                return;
            }

            // Lưu thông tin đầy đủ của librarian
            librarianDAO = new LibrarianDAO(this);
            LibrarianDTO librarian = librarianDAO.getLibrarianByID(username);
            loginSharePreference.saveLogin(librarian);

            if (binding.cbRememberMe.isChecked()) {
                loginSharePreference.isRemember(true);
            } else {
                loginSharePreference.isRemember(false);
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.CustomDialog);
            LayoutInflater inflater = getLayoutInflater();
            builder.setView(inflater.inflate(R.layout.dialog_proccessing, null));
            builder.setCancelable(false);
            AlertDialog dialog = builder.create();
            dialog.show();

            new Handler().postDelayed(() -> {
                dialog.dismiss();
                AlertDialog.Builder builderDialog = new AlertDialog.Builder(this, R.style.CustomDialog);
                DialogLoginSuccessBinding bindingDialog = DialogLoginSuccessBinding.inflate(getLayoutInflater());
                builderDialog.setView(bindingDialog.getRoot());
                AlertDialog dialogLogin = builderDialog.create();

                bindingDialog.btnLoginSuccess.setOnClickListener(view -> {
                    dialogLogin.dismiss();
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                    finish();
                });

                dialogLogin.show();
            }, 1500);
        });
    }
}

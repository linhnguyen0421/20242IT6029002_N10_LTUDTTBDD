package com.librarymanager_n10.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.librarymanager_n10.database.ManagerBookDataBase;
import com.librarymanager_n10.dto.LibrarianDTO;

import java.util.ArrayList;

public class LibrarianDAO {

    private final ManagerBookDataBase db;

    public LibrarianDAO(Context context) {
        this.db = new ManagerBookDataBase(context);
    }

    // Get librarian ID as int from string ID
    public int getLibrarianUsernameByID(String id) {
        int result = -1;
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Librarian WHERE librarianID = ?";
        Cursor cursor = dbReadable.rawQuery(sql, new String[]{id});
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            result = cursor.getShort(0);
        }
        cursor.close();
        dbReadable.close();
        return result;
    }

    // Check password of librarian
    public int checkPasswordLibrarian(String id, String password) {
        int result = -1;
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Librarian WHERE librarianID = ? AND password = ?";
        Cursor cursor = dbReadable.rawQuery(sql, new String[]{id, password});
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            result = 1;
        }
        cursor.close();
        dbReadable.close();
        return result;
    }

    // Get librarian by ID
    public LibrarianDTO getLibrarianByID(String id) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Librarian WHERE librarianID = ?";
        Cursor cursor = dbReadable.rawQuery(sql, new String[]{id});
        LibrarianDTO librarianDTO = new LibrarianDTO();

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            librarianDTO.setId(cursor.getString(0));
            librarianDTO.setName(cursor.getString(1));
            librarianDTO.setPassword(cursor.getString(2));
            librarianDTO.setRole(cursor.getString(3));
        }

        cursor.close();
        dbReadable.close();
        return librarianDTO;
    }

    // Edit librarian
    public long editLibrarian(LibrarianDTO librarianDTO) {
        long result = -1;
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("librarianID", librarianDTO.getId());
        values.put("librarianName", librarianDTO.getName());
        values.put("password", librarianDTO.getPassword());
        values.put("role", librarianDTO.getRole());

        try {
            result = dbWritable.update("Librarian", values, "librarianID = ?", new String[]{librarianDTO.getId()});
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbWritable.close();
        }

        return result;
    }

    // Check if username exists
    public boolean checkUsernameExist(String id) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Librarian WHERE librarianID = ?";
        Cursor cursor = dbReadable.rawQuery(sql, new String[]{id});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        dbReadable.close();
        return exists;
    }

    // Insert librarian
    public long insertLibrarian(LibrarianDTO librarianDTO) {
        long result = -1;
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("librarianID", librarianDTO.getId());
        values.put("librarianName", librarianDTO.getName());
        values.put("password", librarianDTO.getPassword());
        values.put("role", librarianDTO.getRole());

        try {
            result = dbWritable.insert("Librarian", null, values);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbWritable.close();
        }

        return result;
    }

    // Get all librarians
    public ArrayList<LibrarianDTO> getAllLibrarian() {
        ArrayList<LibrarianDTO> listLibrarian = new ArrayList<>();
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT * FROM Librarian";
        Cursor cursor = dbReadable.rawQuery(sql, null);

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                LibrarianDTO librarianDTO = new LibrarianDTO();
                librarianDTO.setId(cursor.getString(0));
                librarianDTO.setName(cursor.getString(1));
                librarianDTO.setPassword(cursor.getString(2));
                librarianDTO.setRole(cursor.getString(3));
                listLibrarian.add(librarianDTO);
                cursor.moveToNext();
            }
        }

        cursor.close();
        dbReadable.close();
        return listLibrarian;
    }
}

package com.librarymanager_n10.fragment.statistical;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.librarymanager_n10.adapter.Top10Adapter;
import com.librarymanager_n10.dao.LibraryLoanSlipDAO;
import com.librarymanager_n10.databinding.FragmentTop10Binding;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.viewmodel.SharedViewModel;

import java.util.ArrayList;

public class Top10Fragment extends Fragment {

    private LibraryLoanSlipDAO loanSlipDAO;
    private ArrayList<BookDTO> listBook;
    private Top10Adapter adapter;
    private SharedViewModel sharedViewModel;

    private FragmentTop10Binding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTop10Binding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.reTopRecyclerView.setHasFixedSize(true);
        binding.reTopRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        loanSlipDAO = new LibraryLoanSlipDAO(requireContext());
        listBook = loanSlipDAO.getTop10Book();

        if (!listBook.isEmpty()) {
            adapter = new Top10Adapter(requireContext(), listBook);
            binding.reTopRecyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }

        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        sharedViewModel.getSearchText().observe(getViewLifecycleOwner(), newText -> {
            ArrayList<BookDTO> filterList = new ArrayList<>();
            for (BookDTO book : listBook) {
                if (book.getName().toLowerCase().contains(newText.toLowerCase())) {
                    filterList.add(book);
                }
            }

            binding.reTopRecyclerView.setAdapter(new Top10Adapter(requireContext(), filterList));
            adapter.notifyDataSetChanged();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

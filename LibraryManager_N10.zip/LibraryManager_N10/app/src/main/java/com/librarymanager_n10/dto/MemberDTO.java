package com.librarymanager_n10.dto;

public class MemberDTO {
    private int id;
    private String name;
    private String birthYear;

    public MemberDTO() {
        // Default constructor
    }

    public MemberDTO(int id, String name, String birthYear) {
        this.id = id;
        this.name = name;
        this.birthYear = birthYear;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthYear() {
        return birthYear;
    }

    public void setBirthYear(String birthYear) {
        this.birthYear = birthYear;
    }

    @Override
    public String toString() {
        return id + " - " + name + " - " + birthYear;
    }
}

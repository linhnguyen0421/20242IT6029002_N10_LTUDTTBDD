package com.librarymanager_n10.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.librarymanager_n10.database.ManagerBookDataBase;
import com.librarymanager_n10.dto.BookDTO;
import com.librarymanager_n10.dto.LibraryLoanSlipDTO;

import java.util.ArrayList;

public class LibraryLoanSlipDAO {
    private final ManagerBookDataBase db;

    public LibraryLoanSlipDAO(Context context) {
        db = new ManagerBookDataBase(context);
    }

    public ArrayList<LibraryLoanSlipDTO> getAllLoanSlips() {
        ArrayList<LibraryLoanSlipDTO> list = new ArrayList<>();
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        Cursor cursor = dbReadable.rawQuery("SELECT * FROM LibraryLoanSlip", null);
        if (cursor.moveToFirst()) {
            do {
                list.add(new LibraryLoanSlipDTO(
                        cursor.getInt(0),
                        cursor.getInt(3),
                        cursor.getString(1),
                        cursor.getInt(2),
                        cursor.getString(4),
                        cursor.getInt(5)
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        dbReadable.close();
        return list;
    }

    public boolean deleteLoanSlip(int id) {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        Cursor cursor = dbWritable.rawQuery("DELETE FROM LibraryLoanSlip WHERE loanSlipID = ?", new String[]{String.valueOf(id)});
        boolean deleted = cursor.getCount() > 0;
        cursor.close();
        dbWritable.close();
        return deleted;
    }

    public ArrayList<BookDTO> getTop10Book() {
        ArrayList<BookDTO> list = new ArrayList<>();
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT LibraryLoanSlip.bookID, COUNT(LibraryLoanSlip.bookID) AS count, " +
                "Book.bookName, Book.rentalFee, Book.categoryID " +
                "FROM LibraryLoanSlip " +
                "INNER JOIN Book ON LibraryLoanSlip.bookID = Book.bookID " +
                "GROUP BY LibraryLoanSlip.bookID " +
                "ORDER BY count DESC LIMIT 10";
        Cursor cursor = dbReadable.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                list.add(new BookDTO(
                        cursor.getInt(0),
                        cursor.getString(2),
                        cursor.getInt(3),
                        cursor.getInt(4),
                        cursor.getInt(1)
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        dbReadable.close();
        return list;
    }

    public int getRevenue() {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT SUM(Book.rentalFee) FROM LibraryLoanSlip " +
                "INNER JOIN Book ON LibraryLoanSlip.bookID = Book.bookID";
        Cursor cursor = dbReadable.rawQuery(sql, null);
        int revenue = 0;
        if (cursor.moveToFirst()) {
            revenue = cursor.getInt(0);
        }
        cursor.close();
        dbReadable.close();
        return revenue;
    }

    public int getRevenueByDate(String startDate, String endDate) {
        Log.d("getRevenueByDate", "Checking revenue from " + startDate + " to " + endDate);
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        String sql = "SELECT SUM(Book.rentalFee) FROM LibraryLoanSlip " +
                "INNER JOIN Book ON LibraryLoanSlip.bookID = Book.bookID " +
                "WHERE LibraryLoanSlip.loanDate BETWEEN ? AND ?";
        Cursor cursor = dbReadable.rawQuery(sql, new String[]{startDate, endDate});
        int revenue = 0;
        if (cursor.moveToFirst()) {
            revenue = cursor.getInt(0);
        }
        cursor.close();
        dbReadable.close();
        Log.d("getRevenueByDate", "Revenue from " + startDate + " to " + endDate + " is: " + revenue);
        return revenue;
    }

    public int getNumberOfLoanSlipByID(String id) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        Cursor cursor = dbReadable.rawQuery("SELECT COUNT(loanSlipID) FROM LibraryLoanSlip WHERE librarianID = ?", new String[]{id});
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        dbReadable.close();
        return count;
    }

    public LibraryLoanSlipDTO getLoanSlipByID(int id) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        Cursor cursor = dbReadable.rawQuery("SELECT * FROM LibraryLoanSlip WHERE loanSlipID = ?", new String[]{String.valueOf(id)});
        LibraryLoanSlipDTO dto = new LibraryLoanSlipDTO(-1, -1, "", -1, "", -1);
        if (cursor.moveToFirst()) {
            dto = new LibraryLoanSlipDTO(
                    cursor.getInt(0),
                    cursor.getInt(3),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getString(4),
                    cursor.getInt(5)
            );
        }
        cursor.close();
        dbReadable.close();
        return dto;
    }

    public LibraryLoanSlipDTO getLibrarianByBookID(int bookId) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        Cursor cursor = dbReadable.rawQuery("SELECT * FROM LibraryLoanSlip WHERE bookID = ?", new String[]{String.valueOf(bookId)});
        LibraryLoanSlipDTO dto = new LibraryLoanSlipDTO(-1, -1, "", -1, "", -1);
        if (cursor.moveToFirst()) {
            dto = new LibraryLoanSlipDTO(
                    cursor.getInt(0),
                    cursor.getInt(3),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getString(4),
                    cursor.getInt(5)
            );
        }
        cursor.close();
        dbReadable.close();
        return dto;
    }

    public boolean insertLoanSlip(LibraryLoanSlipDTO dto) {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        String sql = "INSERT INTO LibraryLoanSlip(librarianID, memberID, bookID, loanDate, status) VALUES(?,?,?,?,?)";
        try {
            dbWritable.execSQL(sql, new Object[]{
                    dto.getIdLibrarian(),
                    dto.getIdMember(),
                    dto.getIdBook(),
                    dto.getDateLoan(),
                    dto.getStatus()
            });
            dbWritable.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            dbWritable.close();
            return false;
        }
    }

    public boolean updateLoanSlip(LibraryLoanSlipDTO dto) {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        String sql = "UPDATE LibraryLoanSlip SET librarianID = ?, memberID = ?, bookID = ?, loanDate = ?, status = ? WHERE loanSlipID = ?";
        try {
            dbWritable.execSQL(sql, new Object[]{
                    dto.getIdLibrarian(),
                    dto.getIdMember(),
                    dto.getIdBook(),
                    dto.getDateLoan(),
                    dto.getStatus(),
                    dto.getId()
            });
            dbWritable.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            dbWritable.close();
            return false;
        }
    }

    public boolean checkLoanSlipExistsByMemberID(int memberId) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        Cursor cursor = dbReadable.rawQuery("SELECT * FROM LibraryLoanSlip WHERE memberID = ?", new String[]{String.valueOf(memberId)});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        dbReadable.close();
        return exists;
    }

    public boolean checkLoanSlipExistsByBookID(int bookId) {
        SQLiteDatabase dbReadable = db.getReadableDatabase();
        Cursor cursor = dbReadable.rawQuery("SELECT * FROM LibraryLoanSlip WHERE bookID = ?", new String[]{String.valueOf(bookId)});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        dbReadable.close();
        return exists;
    }
}
